<?php
$uri = new \CodeIgniter\HTTP\URI();

use App\Models\General_model;

$Gmodel = new General_model();
$uri = current_url(true);
$uri_data = $uri->getSegment(2);

$uri_data_sub = $uri->getSegment(3);

$uri_data_sub = trim($uri_data_sub);
$uri_data_sub2 = $uri->getSegment(3);

$emp_data = $Gmodel->emp_info(session('emp_uname'));
$emp_photo = ($emp_data['cs_emp_code']) ? "https://hrm.comstarauto.com/ex/hr_erp/profile_img/" . $emp_data['cs_emp_code'] . ".jpg" : "assets/img/admin-avatar.png";
$emp_name = session('emp_name');
$show_emp_name = (strlen($emp_name) > 15) ? substr($emp_name, 0, 13) . "...," : $emp_name;
//$emp_session_data = $this->session->all_userdata();
//print_r($emp_session_data);exit;
$profile_active = "";
#ISR
$arr_isr = array('new-entry', 'my_request', 'my_saved_list', 'prepare_report', 'report');
if (in_array($uri_data_sub, $arr_isr)) {
    $isr_tab = "active";
} else {
    $isr_tab = "";
}

#RSR
$arr_rsr = array('new_entry_rsr', 'my_request_rsr', 'ro_approval_list_rsr', 'dept_approval_list_rsr', 'avp_approval_list_rsr', 'vp_approval_list_rsr', 'report_rsr');
if (in_array($uri_data_sub, $arr_rsr)) {
    $rsr_tab = "active";
} else {
    $rsr_tab = "";
}

#PCR
$arr_pcr = array('new_entry_pcr', 'my_request_pcr', 'ro_approval_list_pcr', 'dept_approval_list_pcr', 'avp_approval_list_pcr', 'vp_approval_list_pcr', 'report_pcr');
if (in_array($uri_data_sub, $arr_pcr)) {
    $pcr_tab = "active";
} else {
    $pcr_tab = "";
}

//echo $uri_data_sub."arasu";
?>
<style type="text/css">
    .menu_active {
        color: #fff;
        font-weight: bold;
    }
</style>
<!-- START SIDEBAR-->
<nav class="page-sidebar" id="sidebar">
    <div class="admin-block d-flex">
        <div>
            <img src="<?php echo $emp_photo; ?>" width="45px" />
        </div>
        <div class="admin-info">
            <div class="font-strong" title="<?php echo session('emp_name') ?>"><?php echo $show_emp_name ?></div><small>Sona Comstar</small>
        </div>
    </div>

    <ul class="side-menu metismenu scroller" data-height="100%">
        <li class="<?php echo $isr_tab; ?>">
            <a href="javascript:;"><i class="sidebar-item-icon fa fa-file-archive-o"></i>
                <span class="nav-label">Weekly Updates</span><i class="fa fa-angle-left arrow"></i></a>
            <ul class="nav-2-level collapse">

                <!--<li class="<?php echo $profile_active; ?>" >
								<a href="<?php echo base_url() . "ot_control/dashboard"; ?>"><i class="sidebar-item-icon fa fa-dashboard"></i>
									<span class="nav-label <?php if ($uri_data_sub == 'dashboard') {
                                                                echo 'menu_active';
                                                            } ?>">Dashboard</span>
								</a>
							</li>-->

                <?php $new_entry = $Gmodel->page_authentication(NEW_ENTRY);
                if ($new_entry['result']) { ?>
                    <li class="<?php echo $profile_active; ?>">
                        <a href="<?php echo base_url() . "/new-entry"; ?>"><i class="sidebar-item-icon fa fa-paper-plane"></i>
                            <span class="nav-label <?php if ($uri_data_sub == 'new-entry') {
                                                        echo 'menu_active';
                                                    } ?>">Create New</span>
                        </a>
                    </li>
                <?php } ?>

                <?php $my_request = $Gmodel->page_authentication(MY_REQUEST);
                if ($my_request['result']) { ?>

                    <!--<li class="<?php echo $profile_active; ?>" >
									<a href="<?php echo base_url() . "req_control/my_saved_list"; ?>"><i class="sidebar-item-icon fa fa-save"></i>
										<span class="nav-label <?php if ($uri_data_sub == 'my_saved_list') {
                                                                    echo 'menu_active';
                                                                } ?>">My Saved List</span>
									</a>
								</li>-->

                    <li class="<?php echo $profile_active; ?>">
                        <a href="<?php echo base_url() . "/my_request"; ?>"><i class="sidebar-item-icon fa fa-user-circle"></i>
                            <span class="nav-label <?php if ($uri_data_sub == 'my_request') {
                                                        echo 'menu_active';
                                                    } ?>">Focus Point List</span>
                        </a>
                    </li>

                <?php } ?>


                <?php $prepare_report = $Gmodel->page_authentication(PREPARE_REPORT);
                if ($prepare_report['result']) { ?>
                    <li class="<?php echo $profile_active; ?>">
                        <a href="<?php echo base_url() . "/prepare_report"; ?>"><i class="sidebar-item-icon fa fa-envelope"></i>
                            <span class="nav-label <?php if ($uri_data_sub == 'prepare_report') {
                                                        echo 'menu_active';
                                                    } ?>">Send Mail</span>
                        </a>
                    </li>
                    <!--<li class="<?php echo $profile_active; ?>" >
									<a href="<?php echo base_url() . "/req_control/report"; ?>"><i class="sidebar-item-icon fa fa-file-text-o"></i>
										<span class="nav-label <?php if ($uri_data_sub == 'report') {
                                                                    echo 'menu_active';
                                                                } ?>">Report</span>
									</a>
								</li>-->
                <?php } ?>

            </ul>

        </li>




        <li class="<?php echo $profile_active; ?>">
            <a href="<?php echo base_url() . "user_control/logout"; ?>"><i class="sidebar-item-icon fa fa-power-off"></i>
                <span class="nav-label">Logout</span>
            </a>
        </li>


    </ul>

</nav>
<!-- END SIDEBAR-->