<?php
$uri = new \CodeIgniter\HTTP\URI();

use App\Models\General_model;

$uri = current_url(true);
// $uri_slug = $this->uri->segment(1);
$uri_slug = $uri->getSegment(2);
$session = session();
$Gmodel = new General_model();

$emp_data = $Gmodel->emp_info(session('emp_uname'));
$emp_photo = ($emp_data['cs_emp_code']) ? "https://hrm.comstarauto.com/ex/hr_erp/profile_img/" . $emp_data['cs_emp_code'] . ".jpg" : "public/assets/img/admin-avatar.png";

#NEWS
//$leave_request = $this->attendance_model->leave_request("status='Open' AND ");
?>
<!-- START HEADER-->

<style type="text/css">
    .hamburger-menu-button {
        width: 30px;
        height: 30px;
        padding: 6px;
        display: block;
        position: relative;
        margin-top: 0px;
        z-index: 100;
        //background: #2980b9;
        background: #009999;
        //background-image: url("assets/img/logo.png");
        border: 3px solid white;
        box-sizing: content-box;
        border-radius: 50%;
        text-indent: 100%;
        color: transparent;
        white-space: nowrap;
        cursor: pointer;
        overflow: hidden;
    }

    .hamburger-menu-button-open {
        top: 50%;
        margin-top: -1px;
        left: 50%;
        margin-left: -12px;
    }

    .hamburger-menu-button-open,
    .hamburger-menu-button-open::before,
    .hamburger-menu-button-open::after {
        position: absolute;
        width: 24px;
        height: 2px;
        background: #fff;
        border-radius: 4px;
        -webkit-transition: all 0.3s;
        transition: all 0.3s;
    }

    .hamburger-menu-button-open::before,
    .hamburger-menu-button-open::after {
        left: 0;
        content: "";
    }

    .hamburger-menu-button-open::before {
        top: 6px;
    }

    .hamburger-menu-button-open::after {
        bottom: 6px;
    }

    .hamburger-menu-button-close {
        background: transparent;
        -webkit-transform: rotate(180deg);
        transform: rotate(180deg);
    }

    .hamburger-menu-button-close::before {
        -webkit-transform: translateY(-6px) rotate(45deg);
        transform: translateY(-6px) rotate(45deg);
    }

    .hamburger-menu-button-close::after {
        -webkit-transform: translateY(6px) rotate(-45deg);
        transform: translateY(6px) rotate(-45deg);
    }
</style>


<header class="header">

    <div class="flexbox flex-1">
        <!-- START TOP-LEFT TOOLBAR-->
        <ul class="nav navbar-toolbar">
            <?php
            //  if (session('emp_category') != 'security') { 
            if (session('emp_category') != 'HR - SECURITY') {
            ?>
                <li>
                    <!--<a class="nav-link sidebar-toggler js-sidebar-toggler">
						<i class="ti-menu"></i>
						<i class="ti-close"></i>
						</a>-->

                    <button id="hamburger-menu" class="hamburger-menu-button nav-link sidebar-toggler js-sidebar-toggler"><span class="hamburger-menu-button-open" id="header_menu_span">Menu</span></button>

                </li> &nbsp;&nbsp;
            <?php } else {
                echo "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;";
            }
            $header_title = "SONA COMSTAR - <span style='color:yellow;'>Purchase - Focus Points</span>";
            ?>

            <div class="rel" style="font-size:16pt;color:#fff;font-family:Arial, Helvetica, sans-serif;"><?php echo $header_title; ?></div>
        </ul>
        <!-- END TOP-LEFT TOOLBAR-->
        <!-- START TOP-RIGHT TOOLBAR-->
        <ul class="nav navbar-toolbar">

            <li class="dropdown dropdown-inbox">
                <!--<a class="nav-link dropdown-toggle" data-toggle="dropdown"><i class="fa fa-envelope-o"></i>
                            <span class="badge badge-primary envelope-badge">asdsadsad</span>
                        </a>
						<span class="badge badge-primary envelope-badge">asdsadsad</span>-->

                <ul class="dropdown-menu dropdown-menu-right dropdown-menu-media">
                    <!--<li class="dropdown-menu-header">
                                <div>
                                    <span><strong>1 New</strong> Message</span>
                                </div>
                            </li>-->

                    <li class="list-group list-group-divider scroller" data-height="240px" data-color="#71808f">
                        <div>

                            <a class="list-group-item" href="<?php echo base_url() . "/idp/index/open" ?>">
                                <div class="media">
                                    <!--<div class="media-img">
                                                <img src="./assets/img/users/u1.jpg" />
                                            </div>-->
                                    <div class="media-body">
                                        <div class="font-strong"> Leave request (2) has waiting for your approval.</div>
                                    </div>
                                </div>
                            </a>

                            <!--<a class="list-group-item" href="<?php echo base_url() . "/idp/index/open" ?>">
                                        <div class="media">
                                            
                                            <div class="media-body">
                                                <div class="font-strong"> </div>1 IDP opened<small class="text-muted float-right">Just now</small>
                                                <div class="font-13">Review and update the status.</div>
                                            </div>
                                        </div>
                                    </a>-->



                        </div>
                    </li>




                </ul>
            </li>


            <li class="dropdown dropdown-user">
                <a class="nav-link dropdown-toggle link" data-toggle="dropdown">
                    <?php
                    //  $encrypter = service('encrypter');
                    ?>
                    <img src="<?php echo $emp_photo; ?>" />
                    <span></span><?php echo session('emp_name') ?><i class="fa fa-angle-down m-l-5"></i></a>
                <ul class="dropdown-menu dropdown-menu-right">
                    <!--<a class="dropdown-item" href="<?php echo base_url() . "/employee/detail/" . session('emp_id'); ?>"><i class="fa fa-user"></i>Profile</a>-->
                    <!-- <a class="dropdown-item" href="profile.html"><i class="fa fa-cog"></i>Settings</a>
                            <a class="dropdown-item" href="javascript:;"><i class="fa fa-support"></i>Support</a>
                            <li class="dropdown-divider"></li>-->
                    <a class="dropdown-item" href="<?php echo base_url() . "/user_control/logout"; ?>"><i class="fa fa-power-off"></i>Logout</a>
                </ul>
            </li>
        </ul>
        <!-- END TOP-RIGHT TOOLBAR-->
    </div>



</header>


<!-- END HEADER-->