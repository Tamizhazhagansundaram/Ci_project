<?php

use App\Models\Request_model;
use App\Models\Req_data_update_model;
use App\Models\General_model;

$Gmodel = new General_model();
$Rmodel = new Request_model();
$Umodel = new Req_data_update_model();

?>
<style type="text/css">
    table td,
    table th table tr {
        font-size: 12px;
        font-family: Arial, Helvetica, sans-serif;
    }
</style>
<?php
$mail_content = '<table width="100%" cellpadding="2" cellspacing="1" border="1">
		<tr style="background:#b7dbed;">
			<th>SI.No.</th>
			<th style="text-align:center;">Priority</th>
			<th style="font-weight:bold;text-align:center;">Ref. No</th>
			<th style="font-weight:bold;text-align:center;">Issue/Open Point</th>
			<th style="font-weight:bold;text-align:center;">Action Plan/Improvements</th>
			<th style="font-weight:bold;text-align:center;">Logged Date</th>
			<th style="font-weight:bold;text-align:center;">Target Date</th>
			<th style="font-weight:bold;text-align:center;">Responsible</th>
			<th style="font-weight:bold;text-align:center;">Updates</th>
			<th style="font-weight:bold;text-align:center;">Status</th>
		</tr>';


$si_no = 0;
foreach ($focus_points as $res) {
    $priority = json_decode(PRIORITY, true);
    $priority_class = json_decode(PRIORITY_CLASS, true);

    if ($res['priority'] == 1)
        $back_cls = "#e74c3c";
    else if ($res['priority'] == 2)
        $back_cls = "#f39c12";
    else if ($res['priority'] == 3)
        $back_cls = "#2ecc71";
    else
        $back_cls = "#3498db";


    $status_class = json_decode(STATUS_CLASS, true);

    if ($res['status'] == 'Open')
        $back_cls_new = "#e74c3c";
    else if ($res['status'] == 'Progress')
        $back_cls_new = "#f39c12";
    else if ($res['status'] == 'Closed')
        $back_cls_new = "#2ecc71";
    else if ($res['status'] == 'Hold')
        $back_cls_new = "#3498db";

    $si_no++;
    $responsible = $Gmodel->emp_info($res['responsible']);
    //print_r($responsible['cs_emp_name']);exit;
    $mail_content .= '<tr>';
    $mail_content .= '<td style="text-align:center;">' . $si_no . '</td>';
    $mail_content .= '<td align="center"><div style="background:' . $back_cls . ';width:60px !important;border:1px solid #000;color:#fff;text-align:center;">' . $priority[$res['priority']] . '</div></td>';
    $mail_content .= '<td style="text-align:center;">' . $res['ref_no'] . '</td>';
    $mail_content .= '<td style="text-align:center;">' . $res['open_points'] . '</td>';
    $mail_content .= '<td style="text-align:center;">' . $res['action_plan'] . '</td>';
    $mail_content .= '<td style="text-align:center;">' . date_format_change($res['issue_date'], 1) . '</td>';
    $mail_content .= '<td style="text-align:center;">' . date_format_change($res['target_date'], 1) . '</td>';
    $mail_content .= '<td style="text-align:center;">' . $responsible['cs_emp_name'] . '</td>';
    $mail_content .= '<td style="text-align:left;">' . $res['responsible_updates'] . '</td>';
    $mail_content .= '<td align="center"><div style="background:' . $back_cls_new . ';width:60px !important;border:1px solid #000;color:#fff;text-align:center;">' . $res['status'] . '</div></td>';
    $mail_content .= '</tr>';
}

$mail_content .= '</table><br>';
$mail_content .= "<p align='left' style='font-weight:bold;'>Thanks & Regards <br>J Hemalatha</p>";
echo $mail_content;
?>