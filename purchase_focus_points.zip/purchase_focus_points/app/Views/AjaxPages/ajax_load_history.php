<?php

use App\Models\Request_model;
use App\Models\Req_data_update_model;
use App\Models\General_model;

$Gmodel = new General_model();
$Rmodel = new Request_model();
$Umodel = new Req_data_update_model();
?>
<style type="text/css">
    table td,
    table th table tr {
        font-size: 12px;
        font-family: Arial, Helvetica, sans-serif;
    }
</style>
<?php
$mail_content = '<table width="100%" cellpadding="2" cellspacing="1" border="1">
		<tr style="background:#b7dbed;">
			<th>SI.No.</th>
			<th style="text-align:center;">Updates</th>
			<th style="font-weight:bold;text-align:center;">Updated By</th>
			<th style="font-weight:bold;text-align:center;">Updated On</th>
		</tr>';


$si_no = 0;
foreach ($focus_points_history as $res) {


    $si_no++;
    $responsible = $Gmodel->emp_info($res['updated_by']);
    //print_r($responsible['cs_emp_name']);exit;
    $mail_content .= '<tr>';
    $mail_content .= '<td style="text-align:center;">' . $si_no . '</td>';
    $mail_content .= '<td style="text-align:center;">' . $res['responsible_updates'] . '</td>';
    $mail_content .= '<td style="text-align:center;">' . $responsible['cs_emp_name'] . '</td>';
    $mail_content .= '<td style="text-align:center;">' . date_format_change($res['updated_on'], 1) . '</td>';

    $mail_content .= '</tr>';
}

$mail_content .= '</table><br>';

echo $mail_content;
?>