<?php


use App\Models\Request_model;
use App\Models\Req_data_update_model;
use App\Models\General_model;

$Gmodel = new General_model();
$Rmodel = new Request_model();
$Umodel = new Req_data_update_model();

?>
<style type="text/css">
    .color-box {
        margin: 10px 0;
        padding-left: 10px;
        position: relative;
    }

    .break {
        margin-bottom: 10px !important;
    }

    .color-box .shadow {
        margin: 0;
    }

    .shadow {
        background: #F7F8F9;
        padding: 3px;
        margin: 15px 0 20px;
    }

    .tip-icon {
        background: #92CD59;
    }



    .profile-pic:hover .edit {
        display: block;
    }

    .edit {
        padding-top: 7px;
        padding-right: 7px;
        position: absolute;
        left: 10px;
        top: 0;
        display: none;
    }

    .edit a {
        color: #000;
    }



    body {
        color: #000;
        background: #e2e2e2;
        font-family: 'Roboto', sans-serif;
    }

    .form-control {
        min-height: 41px;
        box-shadow: none;
        border-color: #e1e1e1;
    }

    .form-control:focus {
        border-color: #00cb82;
    }

    .form-control,
    .btn {
        border-radius: 3px;
    }

    .form-header {
        margin: -30px -30px 20px;
        padding: 30px 30px 10px;
        text-align: center;
        background: #00cb82;
        border-bottom: 1px solid #eee;
        color: #fff;
    }

    .form-header h2 {
        font-size: 34px;
        font-weight: bold;
        margin: 0 0 10px;
        font-family: 'Pacifico', sans-serif;
    }

    .form-header p {
        margin: 20px 0 15px;
        font-size: 17px;
        line-height: normal;
        font-family: 'Courgette', sans-serif;
    }

    .signup-form {
        width: 780px;
        margin: 0 auto;
        padding: 30px 0;
    }

    .signup-form form {
        color: #999;
        border-radius: 3px;
        margin-bottom: 15px;
        background: #f0f0f0;
        box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
        padding: 30px;
    }

    .signup-form .form-group {
        margin-bottom: 20px;
    }

    .signup-form label {
        font-weight: normal;
        font-size: 14px;
    }

    .signup-form input[type="checkbox"] {
        position: relative;
        top: 1px;
    }

    .signup-form .btn {
        font-size: 16px;
        font-weight: bold;
        background: #00cb82;
        border: none;
        min-width: 200px;
    }

    .signup-form .btn:hover,
    .signup-form .btn:focus {
        background: #00b073 !important;
        outline: none;
    }

    .signup-form a {
        color: #00cb82;
    }

    .signup-form a:hover {
        text-decoration: underline;
    }
</style>



<table cellspacing="0" border="0" class="table table-striped table-bordered display nowrap" style="font-size:11px;">

    <tr>
        <th width="2%">SI.No</th>
        <th width="5%">Priority</th>
        <th width="5%">Ref No</th>
        <th>Issue/Open Point</th>
        <th>Action Plan / Improvements</th>
        <th>Logged Date</th>
        <th>Target Date</th>
        <th>Responsible</th>
        <th>Updates</th>
        <th>Status</th>
    </tr>
    <?php
    $si_no = 0;
    foreach ($focus_points as $res) {
        $si_no++;
        $responsible = $Gmodel->emp_info($res['responsible']);

        $priority = json_decode(PRIORITY, true);
        $priority_class = json_decode(PRIORITY_CLASS, true);

        $status_class = json_decode(STATUS_CLASS, true);
    ?>
        <tr>
            <td><?php echo $si_no; ?></td>
            <td><span class="<?php echo $priority_class[$res['priority']]; ?>" style="width:50px;"><?php echo $priority[$res['priority']]; ?></span></td>
            <td><?php echo $res['ref_no']; ?></td>
            <td style="background:#fff;" class="profile-pic">

                <div class="color-box break">
                    <div>
                        <?php if (session('emp_uname') == 'jhemalatha' || session('emp_uname') == 'intranet') { ?>
                            <div style="text-align:right;">
                                <div class="edit"><a href="javascript:AjaxModal_Points_Updates('<?php echo $res['id']; ?>')"><i class="fa fa-pencil fa-lg"></i></a></div>
                            </div>
                        <?php } ?>
                        <div class="tip-box">
                            <p style="font-weight:normal;"><?php echo $res['open_points'] ?></p>
                        </div>
                    </div>
                </div>

            </td>

            <td><?php echo $res['action_plan'] ?></td>
            <td><?php echo date_format_change($res['issue_date'], 1) ?></td>
            <td><?php echo date_format_change($res['target_date'], 1) ?></td>
            <td><?php echo $responsible['cs_emp_name']; ?></td>

            <td style="background:#fff;" class="profile-pic">

                <div class="color-box break">
                    <div>
                        <div style="text-align:right;">
                            <div class="edit"><a href="javascript:AjaxModal_Responsible_Updates('<?php echo $res['id']; ?>')" title="Edit"><i class="fa fa-pencil fa-lg"></i></a> &nbsp;&nbsp;&nbsp;&nbsp; <a href="javascript:AjaxModal_Responsible_History('<?php echo $res['id']; ?>')" title="History"><i class="fa fa-history fa-lg"></i></a></div>
                        </div>
                        <div class="tip-box">
                            <p style="font-weight:normal;"><?php echo $res['responsible_updates'] ?></p>
                        </div>
                    </div>
                </div>

            </td>

            <td><span class="<?php echo $status_class[$res['status']]; ?>" style="width:58px;"><?php echo $res['status'] ?></span></td>
        </tr>


    <?php } ?>

</table>