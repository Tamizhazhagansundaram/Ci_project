<?php

use App\Models\General_model;

$session = session();
$Gmodel = new General_model();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <META HTTP-EQUIV="CACHE-CONTROL" CONTENT="NO-CACHE">
    <META HTTP-EQUIV="EXPIRES" CONTENT="Mon, 22 Jul 2002 11:12:01 GMT">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <base href="<?php echo base_url(); ?>">
    <link rel="shortcut icon" href="<?php echo ASSETS ?>assets/img/favicon.ico" />
    <!-- GLOBAL MAINLY STYLES-->
    <link href="<?php echo ASSETS ?>assets/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="<?php echo ASSETS ?>assets/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
    <link href="<?php echo ASSETS ?>assets/vendors/themify-icons/css/themify-icons.css" rel="stylesheet" />
    <!-- PLUGINS STYLES-->
    <link href="<?php echo ASSETS ?>assets/vendors/DataTables/datatables.min.css" rel="stylesheet" />
    <link href="<?php echo ASSETS ?>assets/vendors/DataTables/buttons.dataTables.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo ASSETS ?>assets/vendors/DataTables/fixedHeader.bootstrap4.css">
    <link rel="stylesheet" href="<?php echo ASSETS ?>assets/vendors/DataTables/fixedColumns.bootstrap4.min.css">

    <link href="<?php echo ASSETS ?>assets/vendors/select2/dist/css/select2.min.css" rel="stylesheet" />
    <link href="<?php echo ASSETS ?>assets/vendors/sweet-alert/sweetalert.css" rel="stylesheet">
    <link href="<?php echo ASSETS ?>assets/vendors/toastr/toastr.css" rel="stylesheet" />
    <link href="<?php echo ASSETS ?>assets/vendors/bootstrap-datepicker/dist/css/bootstrap-datepicker3.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo ASSETS ?>assets/vendors/summernote/summernote-bs4.css">
    <!-- THEME STYLES-->
    <link href="<?php echo ASSETS ?>assets/css/main.min.css" rel="stylesheet" />
    <link href="<?php echo ASSETS ?>assets/css/themes/org_theme.css" rel="stylesheet" id="theme-style">
    <!-- PAGE LEVEL STYLES-->
    <style type="text/css">
        .dataTables_length {
            float: right;
        }

        ;

        .test {
            color: red;
            font-weight: bold;
        }

        .modal-header {
            min-height: 16.43px;
            padding: 15px;
            border-bottom: 1px solid #0f78ad;
            background: #5DADD9;
        }

        .modal-header .close {
            margin-top: -2px
        }

        .modal-title {
            margin: 0;
            line-height: 1.42857143;
            color: #FFF
        }

        .modal-body {
            position: relative;
            padding: 15px
        }

        .modal-footer {
            padding: 15px;
            text-align: right;
            /*border-top: 1px solid #e5e5e5*/
            border-top: 1px solid #0f78ad;
            background: #5DADD9;
        }
    </style>
</head>

<!--
has-animation fixed-layout sidebar-mini
fixed-navbar has-animation sidebar-mini
-->

<body class="<?php echo LAYOUT_DESIGN; ?>">
    <div class="page-wrapper">
        <?php echo $header;
        echo $sidebar;
        ?>

        <div class="content-wrapper">
            <!-- START PAGE CONTENT-->
            <!--<div class="page-heading">
                <h1 class="page-title">Plants</h1>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="index.html"><i class="la la-home font-20"></i></a>
                    </li>
                    <li class="breadcrumb-item">DataTables</li>
                </ol>
            </div>-->
            <div class="page-content fade-in-up" id="plant_list">
                <div class="ibox">
                    <div class="ibox-head ibox_title_cls">
                        <div class="ibox-title">Focus Point List</div>
                        <div>
                            <form method="post" name="frm_search" id="frm_search" autocomplete="off">
                                <table>
                                    <tr>

                                        <td style="width:150px;">
                                            <select class="form-control select2_demo_1" name="status" id="status" required="required" style="width:100%">
                                                <option value="">Status - ALL</option>
                                                <option value="Open">Open</option>
                                                <option value="Progress">Progress</option>
                                                <option value="Closed">Closed</option>
                                            </select>
                                        </td>
                                    </tr>
                                </table>
                            </form>
                        </div>
                    </div>
                    <div class="ibox-body" id="show_result"></div>
                </div>

            </div>
            <!-- END PAGE CONTENT-->
            <?php echo $footer; ?>
        </div>
    </div>


    <!-- BEGIN PAGA BACKDROPS-->
    <div class="sidenav-backdrop backdrop"></div>
    <div class="preloader-backdrop">
        <div class="page-preloader">Loading</div>
    </div>
    <!-- END PAGA BACKDROPS-->

    <div class="modal fade" id="ultraModal_po_upload" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Status Updates </h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>
                <div class="modal-body" id="modal-body">
                    <form method="post" name="frm_po_upload" id="frm_po_upload">
                        <div class="row">

                            <div class="col-sm-12 form-group required control-label">
                                <label class="control-label">Updates: <input type="hidden" name="ns_q_modal" id="ns_q_modal"></label>
                                <textarea name="description" class="form-control textarea_update" id="description" rows="10" cols="70"></textarea>
                            </div>



                            <div class="col-sm-12 form-group required control-label">
                                <label class="control-label">Status: </label>
                                <select name="status_new" id="status_new" class="form-control">
                                    <?php if (session('emp_uname') == 'jhemalatha' || session('emp_uname') == 'intranet') { ?>
                                        <option value="Open">Open</option>
                                    <?php } ?>
                                    <option value="Progress" selected>Progress</option>
                                    <?php if (session('emp_uname') == 'jhemalatha') { ?>
                                        <option value="Hold" selected>Hold</option>
                                        <option value="Closed">Closed</option>
                                        <option value="Delete">Delete</option>
                                    <?php } ?>
                                </select>
                            </div>

                            <!--<div class="col-sm-12 form-group required control-label">
								<label class="control-label">Remarks: </label>
								<textarea class="form-control" name="po_remarks" id="po_remarks" required="required" rows="5"></textarea>
							 </div>-->
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <!--<button class="btn btn-purple" type="button" onClick="SaveRows('1X3erM34edfw00Ux');" style="cursor:pointer;">Save Only</button>-->
                    <button class="btn btn-purple" type="button" onClick="SaveFile();" style="cursor:pointer;"><i class="fa fa-upload"></i> Save</button>
                    <button data-dismiss="modal" class="btn btn-default" type="button" style="cursor:pointer;"><i class="fa fa-close"></i> Close</button>
                </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="ultraModal_po_upload_new" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Focus Point - Update</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>
                <div class="modal-body" id="modal-body">
                    <form method="post" name="frm_point_update" id="frm_point_update">
                        <div class="row">

                            <div class="col-sm-12 form-group required control-label">
                                <label class="control-label">Open Points / Issues: <input type="hidden" name="ns_q_modal_new" id="ns_q_modal_new"></label>
                                <textarea name="open_points" class="form-control textarea" id="open_points" rows="8" cols="70"></textarea>
                            </div>

                            <div class="col-sm-12 form-group required control-label">
                                <label class="control-label">Action Plan / Improvements:</label>
                                <textarea name="action_plan" class="form-control textarea" id="action_plan" rows="8" cols="70"></textarea>
                            </div>

                            <div class="col-sm-12 form-group required control-label">
                                <label class="control-label">Responsible: </label>
                                <select name="responsible" id="responsible" class="form-control select2" required>
                                    <option value="">Select</option>
                                    <?php foreach ($emp_list as $row_emp_list) {
                                        $emp_info = $Gmodel->emp_info_by_cond("cs_emp_username = '" . $row_emp_list . "'", 1);
                                    ?>
                                        <option value="<?php echo $emp_info['cs_emp_username']; ?>"><?php echo $emp_info['cs_emp_name']; ?></option>
                                    <?php } ?>
                                </select>
                            </div>

                            <!--<div class="col-sm-12 form-group required control-label">
								<label class="control-label">Priority: </label>
								<select name="priority" id="priority" class="form-control">
									<option value="">Select</option>
									<?php foreach ($priority as $key => $row_priority) { ?>
									<option value="<?php echo $key; ?>"><?php echo $row_priority; ?></option>
									<?php } ?>
								</select>
							 </div>
							 
							<div class="col-sm-12 form-group required control-label">
								<label class="control-label">Status: </label>
								<select name="status_new" id="status_new" class="form-control">
									<option value="Progress" selected>Progress</option>
									<?php if (session('emp_uname') == 'jhemalatha') { ?>
									<option value="Closed">Closed</option>
									<?php } ?>
								</select>
							 </div>-->

                            <!--<div class="col-sm-12 form-group required control-label">
								<label class="control-label">Remarks: </label>
								<textarea class="form-control" name="po_remarks" id="po_remarks" required="required" rows="5"></textarea>
							 </div>-->
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <!--<button class="btn btn-purple" type="button" onClick="SaveRows('1X3erM34edfw00Ux');" style="cursor:pointer;">Save Only</button>-->
                    <button class="btn btn-purple" type="button" onClick="SavePoint();" style="cursor:pointer;"><i class="fa fa-upload"></i> Save</button>
                    <button data-dismiss="modal" class="btn btn-default" type="button" style="cursor:pointer;"><i class="fa fa-close"></i> Close</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="ultraModal_history" role="dialog" aria-labelledby="ultraModal-Label" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Updates - History</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                </div>
                <div class="modal-body" id="history_result">

                </div>
                <div class="modal-footer">
                    <!--<button class="btn btn-purple" type="button" onClick="SaveRows('1X3erM34edfw00Ux');" style="cursor:pointer;">Save Only</button>-->
                    <button data-dismiss="modal" class="btn btn-default" type="button" style="cursor:pointer;"><i class="fa fa-close"></i> Close</button>
                </div>
            </div>
        </div>
    </div>


    <!-- CORE PLUGINS-->
    <script src="<?php echo ASSETS ?>assets/vendors/jquery/dist/jquery.min.js" type="text/javascript"></script>
    <script src="<?php echo ASSETS ?>assets/vendors/popper.js/dist/umd/popper.min.js" type="text/javascript"></script>
    <script src="<?php echo ASSETS ?>assets/vendors/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="<?php echo ASSETS ?>assets/vendors/metisMenu/dist/metisMenu.min.js" type="text/javascript"></script>
    <!-- PAGE LEVEL PLUGINS-->
    <script src="<?php echo ASSETS ?>assets/vendors/DataTables/datatables.min.js" type="text/javascript"></script>
    <script src="<?php echo ASSETS ?>assets/vendors/DataTables/dataTables.buttons.min.js"></script>
    <script src="<?php echo ASSETS ?>assets/vendors/DataTables/buttons.flash.min.js"></script>
    <script src="<?php echo ASSETS ?>assets/vendors/DataTables/jszip.min.js"></script>
    <script src="<?php echo ASSETS ?>assets/vendors/DataTables/pdfmake.min.js"></script>
    <script src="<?php echo ASSETS ?>assets/vendors/DataTables/vfs_fonts.js"></script>
    <script src="<?php echo ASSETS ?>assets/vendors/DataTables/buttons.html5.min.js"></script>
    <script src="<?php echo ASSETS ?>assets/vendors/DataTables/buttons.print.min.js"></script>
    <script src="<?php echo ASSETS ?>assets/vendors/DataTables/buttons.colVis.min.js"></script>
    <script src="<?php echo ASSETS ?>assets/vendors/DataTables/dataTables.fixedHeader.min.js" type="text/javascript"></script>
    <script src="<?php echo ASSETS ?>assets/vendors/DataTables/dataTables.fixedColumns.min.js" type="text/javascript"></script>

    <script src="<?php echo ASSETS ?>assets/vendors/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
    <script src="<?php echo ASSETS ?>assets/vendors/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js" type="text/javascript"></script>
    <script src="<?php echo ASSETS ?>assets/vendors/loader/loadingoverlay.min.js" type="text/javascript"></script>
    <script src="<?php echo ASSETS ?>assets/vendors/sweet-alert/sweetalert.js" type="text/javascript"></script>
    <script src="<?php echo ASSETS ?>assets/vendors/toastr/toastr.js" type="text/javascript"></script>
    <script src="<?php echo ASSETS ?>assets/vendors/summernote/summernote-bs4.min.js" type="text/javascript"></script>
    <!-- CORE SCRIPTS-->
    <script src="<?php echo ASSETS ?>assets/js/app.min.js" type="text/javascript"></script>
    <script src="<?php echo ASSETS ?>assets/vendors/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
    <!-- PAGE LEVEL SCRIPTS-->
    <script src="<?php echo ASSETS ?>assets/vendors/jquery-validation/bootstrapValidator.min.js" type="text/javascript"></script>

    <script type="text/javascript">
        var $base_url = $("base").attr("href");

        $('#status').change(function() {
            filter_records();
        });
        //$('#status').trigger('change');

        filter_records();

        function filter_records() {
            //var $base_url =$("#base_url").val();
            $("#show_result").LoadingOverlay("show", {
                background: "rgba(100, 100, 100, 0.5)"
            });
            $("#show_result").LoadingOverlay("show");
            var form_data = $("#frm_search").serialize();
            $.ajax({
                url: $base_url + "/Ajax-MyRequest",
                dataType: 'html',
                /*cache: false,
                contentType: false,
                processData: false,*/
                data: form_data,
                type: 'POST',
                success: function(data) {
                    $("#show_result").html(data);
                    $("#show_result").LoadingOverlay("hide", true);
                }
            });
        }


        function AjaxModal_Responsible_Updates(id) {
            $('#ultraModal_po_upload').modal('show', {
                backdrop: 'static'
            });

            $.ajax({
                url: $base_url + "/getResponsible-Updates",
                type: "POST",
                //'async': true,
                //data : { rowId : id, bar : 'foo' },
                data: {
                    id: id
                },
                dataType: 'json',
                success: function(response) {
                    //alert(response.description);
                    //$('#description').val(response.responsible_updates);
                    $("#description").summernote('code', response.responsible_updates);

                    //$('#priority').val(response.priority);
                    $('#status_new').val(response.status_new);
                    //var result = response.
                    //alert(response.description);
                    //$('#ultraModal-2 .modal-body').html(response);

                }
            });

            /*$('#ultraModal_po_upload').modal('show', function() {
    $('.datepicker').css('z-index','1600');
});*/

            $('#ns_q_modal').val(id);
            //$('#isr_label').html(ref_no);
        }

        function AjaxModal_Points_Updates(id) {
            $('#ultraModal_po_upload_new').modal('show', {
                backdrop: 'static'
            });

            $.ajax({
                url: $base_url + "/getPoints-Updates",
                type: "POST",
                //'async': true,
                //data : { rowId : id, bar : 'foo' },
                data: {
                    id: id
                },
                dataType: 'json',
                success: function(response) {
                    //alert(response.description);
                    $('#open_points').val(response.open_points);
                    //$(".textarea").summernote('code',response.description);

                    //$('#priority').val(response.priority);
                    $('#action_plan').val(response.action_plan);
                    $('#responsible').val(response.responsible);
                    //var result = response.
                    //alert(response.description);
                    //$('#ultraModal-2 .modal-body').html(response);

                }
            });

            /*$('#ultraModal_po_upload').modal('show', function() {
    $('.datepicker').css('z-index','1600');
});*/

            $('#ns_q_modal_new').val(id);
            //$('#isr_label').html(ref_no);
        }

        function AjaxModal_Responsible_History(id) {
            $('#ultraModal_history').modal('show', {
                backdrop: 'static'
            });

            $.ajax({
                url: $base_url + "/getPoints-History",
                type: "POST",
                //'async': true,
                //data : { rowId : id, bar : 'foo' },
                data: {
                    id: id
                },
                dataType: 'html',
                success: function(response) {
                    //alert(response);
                    $('#history_result').html(response);
                }
            });

        }


        function SaveFile() {
            isValid = true;


            if (isValid == true) {
                swal({
                        title: "Confirmation",
                        text: "Are you sure to update?",
                        type: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#DD6B55",
                        confirmButtonText: "Yes, proceed!",
                        closeOnConfirm: true
                    },
                    function(isConfirm) {
                        if (isConfirm) {
                            var form_data = $("#frm_po_upload").serializeArray();
                            $.ajax({
                                url: $base_url + "/Ajax-UpdateReq",
                                dataType: 'json',
                                data: form_data,
                                type: 'POST',
                                success: function(data) {
                                    //alert(data);

                                    var response = JSON.parse(JSON.stringify(data));
                                    if (data.result == 'error') {
                                        toastr.error(data.msg, 'Missing!!');
                                    } else {
                                        $('#ultraModal_po_upload').modal('hide');
                                        toastr.success(data.msg, 'success');
                                        $('#frm_po_upload').trigger("reset");
                                        filter_records();
                                    }

                                }
                            });
                        } else {
                            $('#btn_submit').prop('disabled', false);
                        }
                    });
            } else {
                toastr.error('Please select file', 'Missing!');
            }
        }


        function SavePoint() {
            isValid = true;


            if (isValid == true) {
                swal({
                        title: "Confirmation",
                        text: "Are you sure to update?",
                        type: "warning",
                        showCancelButton: true,
                        confirmButtonColor: "#DD6B55",
                        confirmButtonText: "Yes, proceed!",
                        closeOnConfirm: true
                    },
                    function(isConfirm) {
                        if (isConfirm) {
                            var form_data = $("#frm_point_update").serializeArray();
                            $.ajax({
                                url: $base_url + "/Ajax-UpdatePoint",
                                dataType: 'json',
                                data: form_data,
                                type: 'POST',
                                success: function(data) {
                                    //alert(data);

                                    var response = JSON.parse(JSON.stringify(data));
                                    if (data.result == 'error') {
                                        toastr.error(data.msg, 'Missing!!');
                                    } else {
                                        $('#ultraModal_po_upload_new').modal('hide');
                                        toastr.success(data.msg, 'success');
                                        $('#frm_point_update').trigger("reset");
                                        filter_records();
                                    }

                                }
                            });
                        } else {
                            $('#btn_submit').prop('disabled', false);
                        }
                    });
            } else {
                toastr.error('Please select file', 'Missing!');
            }
        }


        $('.date_1').datepicker({
            format: "dd/mm/yyyy",
            startDate: "01-01-2019",
            autoclose: true,
            todayHighlight: true,
            container: '#modal-body'
        });

        $('.select2_demo_1').select2();

        $(document).ready(function() {
            //bsCustomFileInput.init();
            $(".textarea_update").summernote({
                height: 200,
                toolbar: [
                    ['style', ['style']],
                    ['font', ['bold', 'italic', 'underline']],
                    ['fontname', ['fontname']],
                    ['fontsize', ['fontsize']],
                    ['color', ['color']],
                    ['para', ['ol', 'ul', 'paragraph', 'height']],
                    ['table', ['table']],
                    ['view', ['undo', 'redo']]
                ],
                callbacks: {
                    onChange: function() {
                        $('#btnSave').prop('disabled', false);
                    }
                }
            });

            $('#img_visibility').select2({
                theme: 'bootstrap4'
            });
        });
    </script>


</body>

</html>