<?php
// echo "jnvljf";
// exit;
?>

<!DOCTYPE html>
<html>

<head>
    <META HTTP-EQUIV="CACHE-CONTROL" CONTENT="NO-CACHE">
    <META HTTP-EQUIV="EXPIRES" CONTENT="Mon, 22 Jul 2002 11:12:01 GMT">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <link rel="shortcut icon" href="assets/img/favicon.ico" />
    <!-- GLOBAL MAINLY STYLES-->
    <link href="<?php echo ASSETS ?>assets/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="<?php echo ASSETS ?>assets/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
    <link href="<?php echo ASSETS ?>assets/vendors/themify-icons/css/themify-icons.css" rel="stylesheet" />
    <!-- THEME STYLES-->
    <link href="<?php echo ASSETS ?>assets/css/main.css" rel="stylesheet" />
    <!-- PAGE LEVEL STYLES-->
    <link href="<?php echo ASSETS ?>assets/css/pages/auth-light.css" rel="stylesheet" />
    <link href="<?php echo ASSETS ?>assets/css/pages/login_css.css" rel="stylesheet" type="text/css" />
</head>

<body class="hold-transition login-page">
    <div class="login-box">

        <!-- /.login-logo -->
        <div class="login-box-body">
            <img src="public/assets/img/logo.png" style="width: 70%;">
            <div class="login-logo">

                <!--<div id="floating_menubar" style="margin-left: 227px; left: 0px; position: fixed; top: 0px; width: 100%; z-index: 500;"><div id="serverinfo"></div></div>-->

                <span style="font-weight: bold;font-size: 19px;font-family:arial;">Purchase - Focus Points</span>
            </div>

            <?php
            // $attributes = array('class' => 'admin_logform', 'id' => 'login-form');
            // echo form_open(base_url() . "login/ajax_login", $attributes) 
            ?>

            <form action="<?php echo base_url() . "/ajax-login" ?>" class="admin_logform" id="login-form" role="form" novalidate="true" data-toggle="validator" method="post" accept-charset="utf-8" autocomplete="off">

                <p style="color: #000;text-align: center;">Please Login to your account</p>

                <div class="form-group has-feedback">
                    <span class="glyphicon glyphicon-user form-control-feedback"></span>
                    <input type="text" name="EmpName" value="" id="EmpName" class="form-control name_letter_allowed" placeholder="Username" maxlength="45" data-error="Enter username" required="" />
                    <!--<input type="hidden" name="ci_csrf_token" value="" id="csrf"  />-->
                    <div class="help-block with-errors"></div>
                </div>

                <div class="form-group has-feedback">
                    <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                    <input type="password" name="EmpPassword" value="" id="EmpPassword" class="form-control pwd_letter_allowed" placeholder="Password" maxlength="45" data-error="Enter password" required="" />
                    <div class="help-block with-errors"></div>
                </div>

                <div class="row">
                    <div class="col-xs-8">
                    </div>
                    <!-- /.col -->
                    <div class="col-xs-12">
						<input type="hidden" name="login_button" value="submit"/>
                        <button type="submit" id="login_button" class="btn btn-success btn-block btn-flat login-button">Sign In</button>

                        <i id="loading" name="loading" class="loader-css fa fa-spinner fa-spin" style="display:none;"></i>
                    </div>

                    <!-- /.col -->
                </div><br>

                <div class="row" id="success_message">
                    <div class="col-xs-12">
                        <div class="alert alert-danger alert-dismissable fade show">
                            <button class="close" data-dismiss="alert" aria-label="Close">×</button>
                            <span id="err_msg"></span>
                        </div>
                    </div>
                </div>

            </form>
            <!-- /.social-auth-links -->
            <br>
        </div>
        <!-- /.login-box-body -->
    </div>
    <!-- /.login-box -->
    <!-- Boostrap google captcha validation -->

    <!-- BEGIN PAGA BACKDROPS-->
    <div class="sidenav-backdrop backdrop"></div>
    <div class="preloader-backdrop">
        <div class="page-preloader">Loading</div>
    </div>
    <!-- END PAGA BACKDROPS-->
    <!-- CORE PLUGINS -->
    <script src="<?php echo ASSETS ?>assets/vendors/jquery/dist/jquery.min.js" type="text/javascript"></script>
    <script src="<?php echo ASSETS ?>assets/vendors/popper.js/dist/umd/popper.min.js" type="text/javascript"></script>
    <script src="<?php echo ASSETS ?>assets/vendors/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="<?php echo ASSETS ?>assets/vendors/metisMenu/dist/metisMenu.min.js" type="text/javascript"></script>
    <!-- PAGE LEVEL PLUGINS -->
    <script src="<?php echo ASSETS ?>assets/vendors/jquery-validation/bootstrapValidator.min.js" type="text/javascript"></script>
    <script src="<?php echo ASSETS ?>assets/vendors/jquery_cookie/jquery.cookie.min.js" type="text/javascript"></script>
    <!-- CORE SCRIPTS-->
    <script src="<?php echo ASSETS ?>assets/js/app.js" type="text/javascript"></script>
    <!-- PAGE LEVEL SCRIPTS-->
    <script type="text/javascript">
        $(document).ready(function() {
            $("#success_message").hide();
            //validator
            $('#login-form').bootstrapValidator({
                    fields: {
                        plant: {
                            validators: {
                                notEmpty: {
                                    message: 'Select plant'
                                }
                            }
                        },
                        EmpName: {
                            validators: {
                                notEmpty: {
                                    message: 'Enter your user name'
                                }
                            }
                        },
                        EmpPassword: {
                            validators: {
                                /* stringLength: {
                                    min: 5,
                                },*/
                                notEmpty: {
                                    message: 'Enter your password'
                                }
                            }
                        }
                    }
                })
                .on('success.form.bv', function(e) {
                    // Prevent form submission
                    e.preventDefault();
                    // Get the form instance
                    var $form = $(e.target);
                    // Get the BootstrapValidator instance
                    var bv = $form.data('bootstrapValidator');
                    $(".btn-block").html('<i class="fa fa-spinner"></i> Please wait...');
                    // Use Ajax to submit form data
                    $.post($form.attr('action'), $form.serialize(), function(data) {
                        if (data.result == "error") {
                            $('#success_message').slideDown({
                                opacity: "show"
                            }, "slow") // Do something ...
                            //alert(data.msg);
                            $('#success_message').show();
                            //$('#success_message').text(data.msg);
                            $("#success_message").slideDown(500).delay(5000).slideUp(500);
                            //$('#success_message').slideUp(5000,{ opacity: "show" }, "slow");
                            $('#err_msg').html(data.msg);
                            $(".btn-block").removeAttr('disabled');
                            $(".btn-block").html('SIGN IN');
                        } else {
                            $('#success_message').hide();
                            //alert(data.msg);
                            window.location.href = data.msg;
                        }

                    }, 'json');
                });
        });

        //For Quick Menu Modal
        $.cookie('quick_menu_modal', 0, {
            path: '/'
        });
        //alert($.cookie('quick_menu_modal'));
    </script>

    <link href='<?php echo ASSETS ?>assets/vendors/bootstrap/dist/css/3_7_bootstrap.min.css' rel='stylesheet' type='text/css'>

</body>

</html>