<?php

use App\Models\Request_model;
use App\Models\Req_data_update_model;
use App\Models\General_model;

$Gmodel = new General_model();
$Rmodel = new Request_model();
$Umodel = new Req_data_update_model();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <META HTTP-EQUIV="CACHE-CONTROL" CONTENT="NO-CACHE">
    <META HTTP-EQUIV="EXPIRES" CONTENT="Mon, 22 Jul 2002 11:12:01 GMT">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width initial-scale=1.0">
    <title><?php echo $pageTitle; ?></title>
    <base href="<?php echo base_url(); ?>">
    <link rel="shortcut icon" href="<?php echo ASSETS ?>assets/img/favicon.ico" />
    <!-- GLOBAL MAINLY STYLES-->
    <link href="<?php echo ASSETS ?>assets/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet" />
    <link href="<?php echo ASSETS ?>assets/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet" />
    <link href="<?php echo ASSETS ?>assets/vendors/themify-icons/css/themify-icons.css" rel="stylesheet" />
    <!-- PLUGINS STYLES-->
    <link href="<?php echo ASSETS ?>assets/vendors/select2/dist/css/select2.min.css" rel="stylesheet" />
    <link href="<?php echo ASSETS ?>assets/vendors/toastr/toastr.css" rel="stylesheet" />
    <link href="<?php echo ASSETS ?>assets/vendors/bootstrap-datepicker/dist/css/bootstrap-datepicker3.min.css" rel="stylesheet" />
    <!--<link href="assets/vendors/bootstrap-datetimepicker/bootstrap-datetimepicker.css" rel="stylesheet" />-->

    <!-- THEME STYLES-->
    <link href="<?php echo ASSETS ?>assets/css/main.min.css" rel="stylesheet" />
    <link href="<?php echo ASSETS ?>assets/css/themes/org_theme.css" rel="stylesheet" id="theme-style">
    <!-- PAGE LEVEL STYLES-->
    <link href="<?php echo ASSETS ?>assets/vendors/sweet-alert/sweetalert.css" rel="stylesheet">
    <link href="<?php echo ASSETS ?>assets/css/pages/panel_css.css" rel="stylesheet">
</head>

<!-- 
<body class="fixed-navbar has-animation sidebar-mini">
fixed-navbar has-animation sidebar-mini
has-animation fixed-layout sidebar-mini
-->

<body class="<?php echo LAYOUT_DESIGN; ?>">
    <div class="page-wrapper">
        <?php echo $header;
        echo $sidebar;
        ?>

        <div class="content-wrapper">
            <!-- START PAGE CONTENT-->
            <!--<div class="page-heading">
                <h1 class="page-title">Plants</h1>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="index.html"><i class="la la-home font-20"></i></a>
                    </li>
                    <li class="breadcrumb-item">DataTables</li>
                </ol>
            </div>-->
            <div class="page-content fade-in-up" id="plant_list">
                <div class="ibox">
                    <?php //echo $visitor_top_menu;
                    ?>
                    <div class="ibox-head ibox_title_cls">
                        <div class="ibox-title" style="font-family:arial;">Open Point - Create New</div>
                        <div class="ibox-tools">
                            <a class="ibox-collapse"><i class="fa fa-minus"></i></a>
                        </div>
                    </div>
                    <div class="ibox-body" id="form_data">
                        <!--<div class="stepwizard">
							<div class="stepwizard-row setup-panel">
								<div class="stepwizard-step col-xs-2"> 
									<a href="javascript:void(0);" onclick="show_tabs_new(1)" data-toggle="tab" class="btn btn-success btn-circle" id="a_link_1">1</a>
									<p><small>Basic Information</small></p>
								</div>
								<div class="stepwizard-step col-xs-2"> 
									<a href="javascript:void(0);" onclick="show_tabs_new(2)" data-toggle="tab" class="btn btn-default btn-circle" id="a_link_2">2</a>
									<p><small>Part Price Info</small></p>
								</div>
								<div class="stepwizard-step col-xs-2"> 
									<a href="javascript:void(0);" onclick="show_tabs_new(3)" data-toggle="tab" class="btn btn-default btn-circle" id="a_link_3">3</a>
									<p><small>Tool Price Info</small></p>
								</div>
								<div class="stepwizard-step col-xs-2"> 
									<a href="javascript:void(0);" onclick="show_tabs_new(4)" data-toggle="tab" class="btn btn-default btn-circle" id="a_link_4">4</a>
									<p><small>Supplier Rating</small></p>
								</div>
								 <div class="stepwizard-step col-xs-2"> 
									<a href="javascript:void(0);" onclick="show_tabs_new(5)" data-toggle="tab" class="btn btn-default btn-circle" id="a_link_5">5</a>
									<p><small>Supplier Comparison</small></p>
								</div>
								
							</div>
						</div>-->
                        <div class="tab-content">



                            <!--<div class="panel panel-primary setup-content" id="step-6">
					<div class="panel-heading">
						 <h3 class="panel-title">Cargo</h3>
					</div>
					<div class="panel-body">
						<div class="form-group">
							<label class="control-label">Company Name</label>
							<input maxlength="200" type="text" required="required" class="form-control" placeholder="Enter Company Name" />
						</div>
						<div class="form-group">
							<label class="control-label">Company Address</label>
							<input maxlength="200" type="text" required="required" class="form-control" placeholder="Enter Company Address" />
						</div>
						<button class="btn btn-success pull-right" type="submit">Finish!</button>
					</div>
				</div>-->

                            <form class="form-horizontal" name="frm_new_request" id="frm_new_request" method="post" autocomplete="off" novalidate="novalidate" action="<?php echo base_url() . "/Ajax-NewReq"; ?>" enctype="multipart/form-data">

                                <!--- TAB 1 - BASIC INFO -->
                                <div class="panel panel-primary setup-content" id="tab-7-1">
                                    <div class="panel-heading">
                                        <h3 class="panel-title">Basic Information</h3>
                                    </div>
                                    <div class="panel-body">




                                        <br>

                                        <div class="row">
                                            <div class="col-sm-6 form-group required control-label">
                                                <label class="control-label">Open Points / Issues</label><br>
                                                <textarea name="open_points" class="form-control textarea" id="open_points" rows="5" cols="70" data-error-msg="Required" required></textarea>
                                            </div>

                                            <div class="col-sm-6 form-group required control-label">
                                                <label class="control-label">Action Plan / Improvements</label><br>
                                                <textarea name="action_plan" class="form-control textarea" id="action_plan" rows="5" cols="70" data-error-msg="Required" required></textarea>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-sm-6 form-group required control-label">
                                                <label class="control-label">Priority</label><br>
                                                <select name="priority" id="priority" class="form-control" required>
                                                    <option value="">Select</option>
                                                    <?php foreach ($priority as $key => $row_priority) { ?>
                                                        <option value="<?php echo $key; ?>"><?php echo $row_priority; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>

                                            <div class="col-sm-6 form-group required control-label">
                                                <label class="control-label">Responsible</label><br>
                                                <select name="responsible" id="responsible" class="form-control select2" required>
                                                    <option value="">Select</option>
                                                    <?php foreach ($emp_list as $row_emp_list) {
                                                        $emp_info = $Gmodel->emp_info_by_cond("cs_emp_username = '" . $row_emp_list . "'", 1);
                                                    ?>
                                                        <option value="<?php echo $emp_info['cs_emp_username']; ?>" <?php if (session('emp_uname') == $emp_info['cs_emp_username']) echo "selected"; ?>><?php echo $emp_info['cs_emp_name']; ?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>


                                        </div>

                                        <div class="row">
                                            <div class="col-sm-6 form-group required control-label date_1">
                                                <label class="control-label form-group required control-label">Logged Date</label><br>
                                                <div class="input-group date">
                                                    <span class="input-group-addon bg-white"><i class="fa fa-calendar"></i></span>
                                                    <input class="form-control datepicker" placeholder="DD/MM/YYYY" type="text" name="issue_date" id="issue_date" value="" data-error-msg="Required" required>
                                                </div>
                                            </div>

                                            <div class="col-sm-6 form-group required control-label date_1">
                                                <label class="control-label form-group required control-label">Target Date</label><br>
                                                <div class="input-group date">
                                                    <span class="input-group-addon bg-white"><i class="fa fa-calendar"></i></span>
                                                    <input class="form-control datepicker" placeholder="DD/MM/YYYY" type="text" name="target_date" id="target_date" value="" required>
                                                </div>
                                            </div>

                                        </div>



                                        <!--<input type="hidden" name="nsq" id="nsq" value="1">
							<input type="hidden" name="nsq_new" id="nsq_new" value="1">
							
						<button class="btn btn-secondary nextBtn pull-left" type="button" name="btn_save" id="btn_save" style="cursor:pointer;">Save</button>-->

                                        <button class="btn btn-primary nextBtn pull-right" type="submit" name="btn_submit_new" id="btn_submit_new" style="cursor:pointer;">Submit</button>
                                    </div>
                                </div>



                            </form>


                        </div>
                    </div>

                </div>
                <!-- END PAGE CONTENT-->
                <?php echo $footer; ?>
            </div>
        </div>

        <div style="display:none;">
            <table id="sample_table">
                <tr id="">
                    <td><span class="sn"></span>.</td>
                    <td><textarea name="description[]" class="form-control description textarea" rows="5" cols="70"></textarea></td>
                    <td>
                        <select name="priority[]" class="form-control priority">
                            <option value="">Select</option>
                            <option value="1">High</option>
                            <option value="2">Medium</option>
                            <option value="3">Low</option>
                            <option value="4">Info</option>
                        </select>
                    </td>
                    <td><a class="btn btn-xs delete-record" data-id="0"><i class="fa fa-trash"></i></a></td>
                </tr>
            </table>

        </div>



        <!-- BEGIN PAGA BACKDROPS-->
        <div class="sidenav-backdrop backdrop"></div>
        <div class="preloader-backdrop">
            <div class="page-preloader">Loading</div>
        </div>
        <!-- END PAGA BACKDROPS-->



        <!-- CORE PLUGINS-->
        <script src="<?php echo ASSETS ?>assets/vendors/jquery/dist/jquery.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS ?>assets/vendors/popper.js/dist/umd/popper.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS ?>assets/vendors/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS ?>assets/vendors/metisMenu/dist/metisMenu.min.js" type="text/javascript"></script>
        <!-- PAGE LEVEL PLUGINS-->
        <script src="<?php echo ASSETS ?>assets/vendors/select2/dist/js/select2.full.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS ?>assets/vendors/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js" type="text/javascript"></script>
        <!--<script src="assets/vendors/bootstrap-datetimepicker/moment-with-locales.js" type="text/javascript"></script>
	<script src="assets/vendors/bootstrap-datetimepicker/bootstrap-datetimepicker.js" type="text/javascript"></script>-->
        <!-- CORE SCRIPTS-->
        <script src="<?php echo ASSETS ?>assets/js/app.min.js" type="text/javascript"></script>
        <!-- PAGE LEVEL SCRIPTS-->
        <script src="<?php echo ASSETS ?>assets/vendors/jquery-validation/validate-bootstrap.jquery.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS ?>assets/vendors/jquery-slimscroll/jquery.slimscroll.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS ?>assets/vendors/loader/loadingoverlay.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS ?>assets/vendors/sweet-alert/sweetalert.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS ?>assets/vendors/toastr/toastr.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS ?>assets/vendors/jquery_cookie/jquery.cookie.min.js" type="text/javascript"></script>
        <script src="<?php echo ASSETS ?>assets/js/scripts/form-plugins.js" type="text/javascript"></script>
        <script type="text/javascript">
            var $base_url = $("base").attr("href");

            /*$(document).delegate('#add-record', 'click', function(e) {
                 e.preventDefault();
            	 var counter = $('#nsq').val();
            	  //alert(counter);
            	 $('#nsq').val(parseInt(counter)+1);
            	  //alert($('#nsq').val());
                 var content = $('#sample_table tr'),
                 size = $('#tbl_posts >tbody >tr').length + 1,
                 element = null,    
                 element = content.clone();
                 element.attr('id', 'rec-'+size);
                 element.find('.delete-record').attr('data-id', size);
            	 element.find('.description').attr('id', 'description_'+size);
            	 element.find('.priority').attr('id', 'priority_'+size);
            	
                 element.appendTo('#tbl_posts_body');
                 element.find('.sn').html(size);
            	 $( ".datepicker" ).datepicker({
            			format: 'dd/mm/yyyy',
            			autoclose: true
            		});
            	 //selectRefresh();
            	 
            	 $("#description_"+size).summernote({
            		height: 200,
            		toolbar: [
            			[ 'style', [ 'style' ] ],
            			[ 'font', [ 'bold', 'italic', 'underline'] ],
            			[ 'fontname', [ 'fontname' ] ],
            			[ 'fontsize', [ 'fontsize' ] ],
            			[ 'color', [ 'color' ] ],
            			[ 'para', [ 'ol', 'ul', 'paragraph', 'height' ] ],
            			[ 'table', [ 'table' ] ],	
            			[ 'view', [ 'undo', 'redo' ] ]
            		],
            		callbacks: {
            			
            		}
            	});


               });
               
            $(document).delegate('a.delete-record', 'click', function(e) {
                 e.preventDefault();
            	 var counter = $('#nsq').val();
            	 $('#nsq').val(parseInt(counter)-1);
                 var didConfirm = confirm("Are you sure You want to delete");
                 if (didConfirm == true) {
                  var id = $(this).attr('data-id');
                  var targetDiv = $(this).attr('targetDiv');
                  $('#rec-' + id).remove();
                  
                //regnerate index number on table
                $('#tbl_posts_body tr').each(function(index) {
                  //alert(index);
                  $(this).find('span.sn').html(index+1);
                });
                return true;
              } else {
                return false;
              }
            });



            function selectRefresh() {
              $('.main .part_no').select2({
                placeholder: "Select",
            	tags:true,
                allowClear: true,
                width: '100%'
              });
            }

            $(document).ready(function() {
              selectRefresh();
            });*/

            $('.select2').select2({
                placeholder: "Select",
                tags: true,
                allowClear: true,
                width: '100%'
            });

            $(function() {
                $('#frm_new_request').validator({
                    validHandlers: {
                        '.customhandler': function(input) {
                            //may do some formatting before validating
                            input.val(input.val().toUpperCase());
                            //return true if valid
                            return input.val() === 'JQUERY' ? true : false;
                        }
                    }
                });

                $('#frm_new_request').submit(function(e) {
                    e.preventDefault();

                    if ($('#frm_new_request').validator('check') < 1) {
                        //alert('Hurray, your information will be saved!');

                        swal({
                                title: "Confirmation",
                                text: "Are you sure to created new request?",
                                type: "warning",
                                showCancelButton: true,
                                confirmButtonColor: "#DD6B55",
                                confirmButtonText: "Yes, proceed!",
                                closeOnConfirm: true
                            },
                            function(isConfirm) {
                                if (isConfirm) {
                                    //var nsq_new = $('#nsq_new').val();
                                    $('#btn_submit').prop('disabled', true);
                                    var form_datas = $("#frm_new_request").serializeArray();
                                    var form_data = new FormData();
                                    //form_data.append('status', status);
                                    $.each(form_datas, function(i, field) {
                                        form_data.append(field.name, field.value);
                                    });
                                    $("#tab-7-1").LoadingOverlay("show");
                                    $.ajax({
                                        url: $('#frm_new_request').attr('action'),
                                        dataType: 'json',
                                        cache: false,
                                        contentType: false,
                                        processData: false,
                                        data: form_data,
                                        type: 'POST',
                                        success: function(data) {
                                            //$("#tab-7-5").LoadingOverlay("hide",true);
                                            var response = JSON.parse(JSON.stringify(data));
                                            //toastr.success('New ISR has been created and sent to RO Approval.', 'Success');
                                            if (data.result == 'error') {
                                                $("#tab-7-1").LoadingOverlay("hide", true);
                                                $('#btn_submit').prop('disabled', false);
                                                toastr.error(data.msg, 'Missing!!');
                                            } else {
                                                alert("Successfully Created!!");
                                                location.reload();
                                              
                                                $("#tab-7-1").LoadingOverlay("hide", true);
                                                swal({
                                                    title: "Success!",
                                                    text: "Successfully Created",
                                                    type: "success"
                                                }, function() {
                                                    //$("#tab-7-1").LoadingOverlay("hide",true);
                                                    // window.location = $base_url + '/' + data.msg;


                                                });
                                            }

                                        }
                                    });
                                } else {
                                    $('#btn_submit').prop('disabled', false);
                                }
                            });
                    }
                })
            })


            $('#btn_submit').click(function() {

                var valid = true;

                //alert($("#initial_doc_2").prop('files')[0]);
                //return false;
                if (valid == true) {
                    swal({
                            title: "Confirmation",
                            text: "Are you sure to created new request?",
                            type: "warning",
                            showCancelButton: true,
                            confirmButtonColor: "#DD6B55",
                            confirmButtonText: "Yes, proceed!",
                            closeOnConfirm: true
                        },
                        function(isConfirm) {
                            if (isConfirm) {
                                //var nsq_new = $('#nsq_new').val();
                                $('#btn_submit').prop('disabled', true);
                                var form_datas = $("#frm_new_request").serializeArray();
                                var form_data = new FormData();
                                //form_data.append('status', status);
                                $.each(form_datas, function(i, field) {
                                    form_data.append(field.name, field.value);
                                });
                                $("#tab-7-1").LoadingOverlay("show");
                                $.ajax({
                                    url: $('#frm_new_request').attr('action'),
                                    dataType: 'json',
                                    cache: false,
                                    contentType: false,
                                    processData: false,
                                    data: form_data,
                                    type: 'POST',
                                    success: function(data) {
                                        //$("#tab-7-5").LoadingOverlay("hide",true);
                                        var response = JSON.parse(JSON.stringify(data));
                                        //toastr.success('New ISR has been created and sent to RO Approval.', 'Success');
                                        if (data.result == 'error') {
                                            $("#tab-7-1").LoadingOverlay("hide", true);
                                            $('#btn_submit').prop('disabled', false);
                                            toastr.error(data.msg, 'Missing!!');
                                        } else {
                                            // alert("Successfully Created!!");
                                            $("#tab-7-1").LoadingOverlay("hide", true);
                                            swal({
                                                title: "Success!",
                                                text: "Successfully Created",
                                                type: "success"
                                            }, function() {
                                                //$("#tab-7-1").LoadingOverlay("hide",true);
                                                window.location = $base_url + '/' + data.msg;
                                                //alert("Successfully Created!!");
                                            });
                                        }

                                    }
                                });
                            } else {
                                $('#btn_submit').prop('disabled', false);
                            }
                        });
                } else {
                    toastr.error('Some field(s) value missing.', 'Missing!');
                }


            });

            //$('.datepicker').datepicker({ autoclose: true,format: 'dd/mmm/yyyy', });

            $(".datepicker").datepicker({
                autoclose: true,
                format: 'DD/MM/YY',
            }).change(function() {
                $(this).valid(); // triggers the validation test        
            });
        </script>
</body>

</html>