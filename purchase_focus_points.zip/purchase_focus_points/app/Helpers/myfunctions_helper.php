<?php
//if ( ! defined('BASEPATH')) exit('No direct script access allowed');

function date_format_change($val = '', $orig = '')
{
	//echo $val;<br>
	if ($orig) {
		$get_date = @explode("-", $val);
		//print_r($get_date);
		$new_date = $get_date[2] . "/" . $get_date[1] . "/" . $get_date[0];
	} else {
		$get_date = @explode("/", $val);
		//print_r($get_date);
		$new_date = $get_date[2] . "-" . $get_date[1] . "-" . $get_date[0];
	}
	return $new_date;
}
function dat($dat)
{
	if ($dat) {
		return date('M d, Y', strtotime($dat));
	}
}
function month_name($month_id)
{
	$monthName = date('F', mktime(0, 0, 0, $month_id, 10)); // March
	return $monthName;
}

function getDatesFromRange($start, $end)
{
	$dates = array($start);
	while (end($dates) < $end) {
		$dates[] = date('Y-m-d', strtotime(end($dates) . ' +1 day'));
	}
	return $dates;
}
function HourDifference($from_time, $to_time)
{
	/*list($hours, $minutes) = explode(':', $from_time);
	$startTimestamp = mktime($hours, $minutes);
	
	list($hours, $minutes) = explode(':', $to_time);
	$endTimestamp = mktime($hours, $minutes);
	
	$seconds = $endTimestamp - $startTimestamp;
	$minutes = ($seconds / 60) % 60;
	$hours = floor($seconds / (60 * 60));
	
	return $hours.':'.$minutes;*/

	list($hours, $minutes) = explode(':', $from_time);
	$startTimestamp = mktime($hours, $minutes);

	list($hours, $minutes) = explode(':', $to_time);
	$endTimestamp = mktime($hours, $minutes);

	$seconds = $endTimestamp - $startTimestamp;
	$minutes = ($seconds / 60) % 60;
	$hours = floor($seconds / (60 * 60));

	if ($hours < 0) {

		list($hours2, $minutes2) = explode(':', $from_time);
		$startTimestamp2 = mktime($hours2, $minutes2);

		list($hours3, $minutes3) = explode(':', '00:00');
		$startTimestamp3 = mktime($hours3, $minutes3);

		list($hours2, $minutes2) = explode(':', '23:59');
		$endTimestamp2 = mktime($hours2, $minutes2);

		list($hours3, $minutes3) = explode(':', $to_time);
		$endTimestamp3 = mktime($hours3, $minutes3);

		$seconds2 = $endTimestamp2 - $startTimestamp2;
		$seconds3 = $endTimestamp3 - $startTimestamp3;

		$minutes4 = (($seconds2 + $seconds3 + 60) / 60) % 60;
		//$minutes3 = ($seconds3 / 60) % 60;

		$hours4 = floor(($seconds2 + $seconds3 + 60) / (60 * 60));
		//$hours3 = floor($seconds3 / (60 * 60));

		return $hours4 . ":" . $minutes4;
	} else
		return $hours . ":" . $minutes;
}
function date_for_db($dat)
{
	if ($dat) {
		$date = str_replace('/', '-', $dat);
		return date('Y-m-d', strtotime($date));
	}
}
function encode_new($value, $str = '')
{
	if ($value) {
		$prefix_string = generateRandomString(10);
		$suffix_string = generateRandomString(8);
		if ($str == '') {
			$value = $value + 875656967;
		}
		$str = rand(11111, 99999) . $prefix_string . base64_encode($value) . $suffix_string . rand(1111, 9999);
		return $str;
	}
}
function decode_new($value, $str = '')
{
	if ($value) {
		//$getData = str_replace('AmdYzo087o2M','',$value);
		//$getData = str_replace('M2o780ozYddmA','',$getData);
		$getData = substr($value, 15);
		$getData = substr($getData, 0, strlen($getData) - 12);
		$getData = base64_decode($getData);
		if ($str == '') {
			$getData = $getData - 875656967;
		}
		return $getData;
	}
}
function generateRandomString($length = 10)
{
	return substr(str_shuffle(str_repeat($x = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', ceil($length / strlen($x)))), 1, $length);
}
function status_cls($status)
{
	if ($status == 'S')
		echo 'btn-info';
	else if ($status == 'A' || $status == 'HRP' || $status == 'AVP')
		echo 'btn-success';
	else if ($status == 'R' || $status == 'RVP')
		echo 'btn-danger';
	else if ($status == 'RR')
		echo 'btn-warning';
	else if ($status == 'E')
		echo 'btn-info';
	else if ($status == 'NE' || $status == 'C')
		echo 'btn-danger';
}
function show_days($dat)
{
	$now = time(); // or your date as well
	$your_date = strtotime($dat);
	$datediff = $now - $your_date;
	return round($datediff / (60 * 60 * 24));
}
function show_days_from_fin($dat, $fin_date)
{
	//$now = time(); // or your date as well
	$your_date = strtotime($dat);
	$fin_date = strtotime($fin_date);
	$datediff = $fin_date - $your_date;
	return round($datediff / (60 * 60 * 24));
}
function getStartAndEndDate($week, $year)
{
	if ($week) {
		$dto = new DateTime();
		$dto->setISODate($year, $week);
		$ret['week_start'] = $dto->format('Y-m-d');
		$dto->modify('+6 days');
		$ret['week_end'] = $dto->format('Y-m-d');
		return $ret;
	}
}

function get_week_no($dat = '')
{
	$date_string = ($dat) ? $dat : date('Y-m-d');
	$date_int = strtotime($date_string);
	$date_date = date($date_int);
	$week_number = date('W', $date_date);
	$week_number = ltrim($week_number, 0);
	return $week_number;
}
