<?php

namespace App\Models;

use CodeIgniter\Model;
use CodeIgniter\HTTP\IncomingRequest;

use Session;

use Config\MyConfig;

$uri = new \CodeIgniter\HTTP\URI();

// use App\Models\EngineerModel;

class General_model extends Model
{
    function userCheck($admin_name)
    {

        $this->portal_db = db_connect("portal_db");
        $builder = $this->portal_db->table('tbl__cs_employee');
        $builder->select('*');
        $builder->where('cs_emp_username', $admin_name);
        $builder->where('cs_emp_status', 'Active');
        $builder->limit(1);
        $query = $builder->get();
        return $query->getRowArray();
    }

    /** Menu and page navigation authentication Starts Here **/
    function page_authentication($menu_control_arr)
    {
        $result = 0;
        $session = session();
        $menu_control_arr = json_decode($menu_control_arr);
        $emp_session_data =  $session->get();
        $menu_emp_group = $menu_control_arr->EMP_GROUP;
        $menu_emp_user = $menu_control_arr->USERS;
        $menu_emp_category = $menu_control_arr->CATEGORY;
        //$menu_emp_user = $menu_control_arr->CATEGORY;
        if (isset($menu_emp_group) && in_array(session('emp_group'), $menu_emp_group)) {
            $result = 1;
        } else if (isset($menu_emp_user) && in_array(session('emp_uname'), $menu_emp_user)) {
            $result = 2;
        } else if (isset($menu_emp_category) && in_array(session('emp_category'), $menu_emp_category)) {
            $result = 3;
        }
        $arr['result'] = $result;
        //print_r($menu_control_arr);
        //echo $result;
        //exit;
        //echo $emp_session_data['emp_category'];
        if ($result == 0) {
            if (session('emp_category') == 'GSR') {
				
                $arr['redirect'] = base_url() . "/my_request";
            } else {
                $arr['redirect'] = base_url();
            }
        }
		//else{
		//	$arr['redirect'] = base_url();
		//}

        return $arr;
    }

    public function activity_tracking($action_name, $action_description = '')
    {
        // $url = base_url() . $this->uri->uri_string();
        $uri = current_url(true);
        $url = base_url() . $uri;

        $action_description = $action_description . " | " . $url;
        $data['user_name'] =  session('emp_uname');
        $data['ip_addr'] =  $_SERVER['SERVER_ADDR'];
        $data['action_name'] =  $action_name;
        $data['action_description'] = $action_description;
        $data['dat'] =  NOW;
        $builder = $this->db->table('activity_tracker');
        $builder->insert($data);
        return true;
    }


    /** Employee Info Starts Here **/
    function emp_info($emp_uname)
    {

        $this->portal_db = db_connect("portal_db");
        $builder = $this->portal_db->table(EMPLOYEE_MASTER);
        $builder->select('*');
        $builder->where('cs_emp_username', $emp_uname);
        //$builder->where('cs_emp_status', 'Active');
        $builder->limit(1);
        $query = $builder->get();
        //echo $this->db->last_query();
        return $query->getRowArray();
    }

    /** Employee Info By cond Starts Here **/
    function emp_info_by_cond($cond, $limit = '')
    {



        $this->portal_db = db_connect("portal_db");
        $builder = $this->portal_db->table(EMPLOYEE_MASTER);
        $builder->select('*');
        $builder->where($cond);
        //$builder->where('cs_emp_status', 'Active');
        if ($limit == 1) {
            $builder->limit(1);
        }

        $query = $builder->get();
        if ($limit == 1) {
            return $query->getRowArray();
        }
        //echo $this->db->last_query();
        return $query->getResultArray();
    }

    public function sessionValidationAjax($ses_role = '')
    {
        if (!session('emp_uname')) {
            $arr_msg = array('result' => 'error', 'msg' => 'Login Expired - Session out. Please Log in again.');
            return json_encode($arr_msg);
        }
		
    }
	  public function sessionValidation($ses_role = '')
	{
		if (!session('emp_uname')) {
			$full_url = base_url(uri_string());
			$explode_base = @explode(base_url(), $full_url);
			//print_r($explode_base);
			if ($explode_base[1]) {
				$rurl = $explode_base[1];
				redirect()->to(base_url() . "?q=" . $rurl);
				
			} else {
				redirect()->to(base_url());
			}
		}
	}
}
