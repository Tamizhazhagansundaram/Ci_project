<?php

namespace App\Models;

use CodeIgniter\Model;
use CodeIgniter\HTTP\IncomingRequest;

use Session;

use Config\MyConfig;
use App\Models\Request_model;

$uri = new \CodeIgniter\HTTP\URI();

// use App\Models\EngineerModel;

class Common_model extends Model
{

    /** Send Mail Starts Here **/
    public function sendMail($to, $subject, $content, $custHeader)
    {
        //print_r($custHeader);
        //echo 'tst'; exit;
        $SerUrlName = base_url();
        $siteurl = "";
        $message = '<style type="text/css">
				table td, table th table tr{
					font-size: 12px;
					font-family: Arial, Helvetica, sans-serif;
				}
			</style>';
        $message .= '<table width="100%" cellpadding="0" cellspacing="0" border="0" align="center">';
        $message .= '<tr><td width="585" align="center">';
        $message .= '<table width="585" cellpadding="0" cellspacing="0" border="0">';
        $message .= '<tr><td width="585">';
        $message .= '<table width="585" cellpadding="0" cellspacing="0" border="0">';

        //$message.='<tr><td width="30%"><img src="'.$SerUrlName.'assets/img/logo.png" width="225" border="0" alt="Rethink your everyday." title="Rethink your everyday." style="display: block;" /></td><td width="70%" align="center" style="font-family:tahoma;font-weight:bold;font-size:18px;color:#E52743;">Price Approval system</td></tr></table></td></tr>';

        //$message.='<tr><td width="585"><img src="'.$SerUrlName.'assets/img/header_btm.jpg" width="100%" height="20" border="0" style="display: block;" /></td></tr>';

        $message .= '<tr><td width="585">';


        /*** Here the dynamic content of the mail part is placed***/
        $message .= $content;

        $message .= '</td></tr></table></td>';
        $message .= '</tr></table></td></tr><tr>';
        $message .= '</td></tr></table></td>';
        $message .= '<td width="21" valign="top" ></td></tr></table></td></tr>';
        $message .= '</table></td></tr></table>';

        // Always set content-type when sending HTML email


        // if($custHeader=='')
        // {
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
        // $headers .= "From: comdev05@sonacomstar.com" . "\r\n";
        // $cc_address = "aarasapandy@sonacomstar.com,comdev03@sonacomstar.com";
        $headers .= "From: intranet.mmn@sonacomstar.com" . "\r\n";
        $cc_address = "jhemalatha@sonacomstar.com,aarasapandy@sonacomstar.com";
        $headers .= "CC: " . $cc_address . "\r\n";
        $header_txt = $headers;

        // }
        // else
        // {
        // if(TEST_MAIL)
        // {
        // $header_txt = $custHeader;
        // $headers = "MIME-Version: 1.0" . "\r\n";
        // $headers .= "Content-type:text/html;charset=iso-8859-1" . "\r\n";
        // $headers .= "From: intranet.mmn@sonacomstar.com" . "\r\n";

        // }
        // else
        // {
        // $headers=$custHeader;
        // $header_txt = $headers;
        // }
        //}
        //echo $header_txt; exit;
        if (TEST_MAIL) {
            $message .= '<br><br><table style="font-family:verdana;font-size:12px;" cellpadding="3" cellspacing="3" border="1" width="60%">';
            $message .= '<tr><td>TO </td><td>' . $to . '</td></tr>';
            $message .= '<tr><td>CC</td><td>' . $header_txt . '</td></tr>';
            $message .= '</table>';
            $to = TEST_MAIL;
        }


        //echo $to."#".$subject."#".$message."#".$headers;exit;
        $mail = mail($to, $subject, $message, $headers);
        //var_dump($mail);

    }
    /** Send Mail Ends Here **/

    function show_months($str = '')
    {
        $arr = array();
        for ($monthNum = 1; $monthNum < 13; $monthNum++) {
            $month_name = date('F', mktime(0, 0, 0, $monthNum, 10));
            $month_name = substr($month_name, 0, 3);
            $arr[$monthNum] = $month_name;
        }
        return $arr;
    }

    function show_year($str = '')
    {
        $arr = array();
        $cur_yr = date('Y') + 1;
        for ($yrNum = 1; $yrNum < 13; $yrNum++) {
            $prev_yr = $cur_yr - $yrNum;
            $arr[$yrNum] = $prev_yr;
        }
        return $arr;
    }
}
