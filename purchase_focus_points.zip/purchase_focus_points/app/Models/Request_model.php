<?php

namespace App\Models;

use CodeIgniter\Model;
use CodeIgniter\HTTP\IncomingRequest;

use Session;

use Config\MyConfig;

$uri = new \CodeIgniter\HTTP\URI();

// use App\Models\EngineerModel;

class Request_model extends Model
{
    function request_list($cond = '', $limit = '')
    {

        $builder = $this->db->table(OPEN_POINTS);
        $builder->select('*');
        $builder->where("status!='Delete'");
        if ($cond) {
            $builder->where($cond);
        }
        $builder->orderBy('id', 'DESC');
        $query = $builder->get();
        if ($limit == 1) {
            return $query->getRowArray();
        } else {
            return $query->getResultArray();
        }
    }

    function responsible_updates($cond = '', $limit = '')
    {

        $builder = $this->db->table(RESPONSIBLE_UPDATES);
        $builder->select('*');
        if ($cond) {
            $builder->where($cond);
        }
        $builder->orderBy('id', 'DESC');
        $query = $builder->get();
        if ($limit == 1) {
            return $query->getRowArray();
        } else {
            return $query->getResultArray();
        }
    }
}
