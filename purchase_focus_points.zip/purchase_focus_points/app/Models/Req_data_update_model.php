<?php

namespace App\Models;

use CodeIgniter\Model;
use CodeIgniter\HTTP\IncomingRequest;

use Session;

use Config\MyConfig;
use App\Models\Request_model;
use App\Models\General_model;
use App\Models\Common_model;
use CodeIgniter\HTTP\Request;

$uri = new \CodeIgniter\HTTP\URI();

// use App\Models\EngineerModel;

class Req_data_update_model extends Model
{
    #Update Data
    public function Req_UpdateEntry($post)
    {
        $Rmodel = new Request_model();
        $id = $_POST['ns_q_modal'];
        $req_info = $Rmodel->request_list("id= '" . $id . "' ", 1);
        $fields_arr = array();
        $fields_arr['responsible_updates'] = $_POST['description'];
        $fields_arr['status'] = $_POST['status_new'];
        $fields_arr['resp_updates_by'] = session('emp_uname');
        $fields_arr['resp_updates_on'] = NOW;
        $fields_arr['updated_by'] = session('emp_uname');
        $fields_arr['updated_on'] = NOW;

        if ($_POST['description']) {
            $builder = $this->db->table(OPEN_POINTS);

            $builder->where('id', $id);
            $builder->update($fields_arr);

            // return true;
            // $this->db->where('id', $id);
            // $this->db->update(OPEN_POINTS, $fields_arr);

            #INSERT FOR HISTORY
            $ins_arr = array();
            $ins_arr['parent_id'] = $id;
            $ins_arr['responsible_updates'] = $_POST['description'];
            $ins_arr['updated_by'] = session('emp_uname');
            $ins_arr['updated_on'] = NOW;
            $ins_arr['status'] = 'Y';

            $builder = $this->db->table(RESPONSIBLE_UPDATES);
            $builder->insert($ins_arr);


            $arr_msg = array('result' => 'success', 'msg' => 'Successfully Updated.');
        } else {
            $arr_msg = array('result' => 'error', 'msg' => 'Missing! - Please check all the fields and submit again.');
        }


        $return_output = @json_encode($arr_msg);
        return $return_output;
    }


    public function Req_UpdatePoint($post)
    {
        $Rmodel = new Request_model();
        $id = $_POST['ns_q_modal_new'];
        $req_info = $Rmodel->request_list("id= '" . $id . "' ", 1);
        $fields_arr = array();
        $fields_arr['open_points'] = $_POST['open_points'];

        $fields_arr['action_plan'] = $_POST['action_plan'];
        $fields_arr['updated_by'] = session('emp_uname');
        $fields_arr['responsible'] = $_POST['responsible'];
        $fields_arr['updated_on'] = NOW;

        if ($_POST['open_points']) {
            $builder = $this->db->table(OPEN_POINTS);

            $builder->where('id', $id);
            $builder->update($fields_arr);

            $arr_msg = array('result' => 'success', 'msg' => 'Successfully Updated.');
        } else {
            $arr_msg = array('result' => 'error', 'msg' => 'Missing! - Please check all the fields and submit again.');
        }


        $return_output = @json_encode($arr_msg);
        return $return_output;
    }


    #NEW REQ ENTRY
    public function Req_NewEntry($post)
    {
        //print_r($_POST);
        $fields_arr = array();
        $fields_arr['open_points'] = $_POST['open_points'];
        $fields_arr['action_plan'] = $_POST['action_plan'];
        $fields_arr['priority'] = $_POST['priority'];
        $fields_arr['responsible'] = $_POST['responsible'];

        $issue_date = date_format_change($_POST['issue_date']);
        $target_date = date_format_change($_POST['target_date']);
        $fields_arr['issue_date'] = $issue_date;
        $fields_arr['target_date'] = $target_date;
        $fields_arr['created_by'] = session('emp_uname');
        $fields_arr['created_on'] = NOW;
        $fields_arr['status'] = "Open";
        if ($fields_arr['open_points']) {
            $rurl = "my_request";

            $builder = $this->db->table(OPEN_POINTS);
            $builder->insert($fields_arr);
            $ins_id = $this->db->insertID();


            $ins_id_new = (strlen($ins_id) == 1) ? "0" . $ins_id : $ins_id;
            $ref_no = 'FOC/' . date('m') . '/' . date('Y') . '/' . $ins_id_new;

            #REF NO UPDATE
            $field_status_arr['ref_no'] = $ref_no;

            $builder = $this->db->table(OPEN_POINTS);

            $builder->where('id', $ins_id);
            $builder->update($field_status_arr);



            $arr_msg = array('result' => 'success', 'msg' => $rurl);
        } else {
            $arr_msg = array('result' => 'error', 'msg' => 'Missing! - Please check all the fields and submit again.');
        }

        $return_output = @json_encode($arr_msg);
        return $return_output;
    }


    public function send_mail($post)
    {

        $Rmodel = new Request_model();
        $Gmodel = new General_model();
        $Cmodel = new Common_model();
        // print_r($_POST);

        $post_elements = $_POST['status'];
        //print_r($post_elements);

        // $post_elements = $this->request->getVar(NULL, TRUE);
        $status = "'" . @implode("','", $post_elements) . "'";

        $data['status'] = $status;
        if ($data['status'])
            $cond = " AND status IN (" . $data['status'] . ")";
        $focus_points = $Rmodel->request_list("responsible !='' " . $cond);

        $mail_content = '<table width="1200" cellpadding="2" cellspacing="2" border="1">
		<tr style="background:#b7dbed;">
			<th>SI.No.</th>
			<th style="text-align:center;">Priority</th>
			<th style="font-weight:bold;text-align:center;">Ref. No</th>
			<th style="font-weight:bold;text-align:center;" width="300">Issue/Open Point</th>
			<th style="font-weight:bold;text-align:center;" width="300">Action Plan/Improvements</th>
			<th style="font-weight:bold;text-align:center;">Logged Date</th>
			<th style="font-weight:bold;text-align:center;">Target Date</th>
			<th style="font-weight:bold;text-align:center;" width="100">Responsible</th>
			<th style="font-weight:bold;text-align:center;" width="300">Updates</th>
			<th style="font-weight:bold;text-align:center;">Status</th>
		</tr>';


        $si_no = 0;
        foreach ($focus_points as $res) {
            $priority = json_decode(PRIORITY, true);
            $priority_class = json_decode(PRIORITY_CLASS, true);

            if ($res['priority'] == 1)
                $back_cls = "#e74c3c";
            else if ($res['priority'] == 2)
                $back_cls = "#f39c12";
            else if ($res['priority'] == 3)
                $back_cls = "#2ecc71";
            else
                $back_cls = "#3498db";


            $status_class = json_decode(STATUS_CLASS, true);

            if ($res['status'] == 'Open')
                $back_cls_new = "#e74c3c";
            else if ($res['status'] == 'Progress')
                $back_cls_new = "#f39c12";
            else if ($res['status'] == 'Closed')
                $back_cls_new = "#2ecc71";
            else if ($res['status'] == 'Hold')
                $back_cls_new = "#868e96";

            $si_no++;
            $responsible = $Gmodel->emp_info($res['responsible']);
            $mail_content .= '<tr>';
            $mail_content .= '<td style="text-align:center;">' . $si_no . '</td>';
            $mail_content .= '<td align="center"><div style="background:' . $back_cls . ';width:60px !important;border:1px solid #000;color:#fff;text-align:center;">' . $priority[$res['priority']] . '</div></td>';
            $mail_content .= '<td style="text-align:center;">' . $res['ref_no'] . '</td>';
            $mail_content .= '<td style="text-align:center;">' . $res['open_points'] . '</td>';
            $mail_content .= '<td style="text-align:center;">' . $res['action_plan'] . '</td>';
            $mail_content .= '<td style="text-align:center;">' . date_format_change($res['issue_date'], 1) . '</td>';
            $mail_content .= '<td style="text-align:center;">' . date_format_change($res['target_date'], 1) . '</td>';
            $mail_content .= '<td style="text-align:center;">' . $responsible['cs_emp_name'] . '</td>';
            $mail_content .= '<td style="text-align:left;">' . $res['responsible_updates'] . '</td>';
            $mail_content .= '<td align="center"><div style="background:' . $back_cls_new . ';width:60px !important;border:1px solid #000;color:#fff;text-align:center;">' . $res['status'] . '</div></td>';
            $mail_content .= '</tr>';
        }

        $mail_content .= '</table><br>';
        $mail_content .= "<p align='left' style='font-weight:bold;'>Thanks & Regards <br>J Hemalatha</p>";

        $subject = "Purchase - Focus Points";

        //echo $mail_content;
        $toMailId = "mvaithiy@sonacomstar.com";


        $cheaders = "MIME-Version: 1.0" . "\r\n";
        $cheaders .= "Content-type:text/html;charset=utf-8" . "\r\n";
        // $cheaders .= "From: Intranet<comdev05@sonacomstar.com>\r\n";
        $cheaders = 'From: Intranet<intranet.mmn@sonacomstar.com>' . "\r" . 'Reply-To: Intranet<intranet.mmn@sonacomstar.com>' . "\r" . 'Return-Path: Intranet<intranet.mmn@sonacomstar.com>';

        $cc_address = "jhemalatha@sonacomstar.com";
        $cc_address = "aarasapandy@sonacomstar.com";
        $cheaders .= "CC: " . $cc_address . "\r\n";
        $send_mail = $Cmodel->sendMail($toMailId, $subject, $mail_content, $cheaders);
        if ($send_mail) {
            #ACTIVITY
            $Gmodel->activity_tracking('Focus points submission', 'Mail_Sent');
        }

        $arr_msg = array('result' => 'success', 'msg' => 'Mail has been sent to SVP.');
        $return_output = @json_encode($arr_msg);
        return $return_output;
    }
}
