<?php

namespace App\Controllers;

use Config\MyConfig;

use App\Models\General_model;

class UserController extends BaseController
{



    /**
     * Log out
     *
     */
    public function logout()
    {
        #ACTIVITY
        $session = session();
        $Gmodel = new General_model();
        $Gmodel->activity_tracking('LOGGED OUT');

        $session->remove('emp_uname');
        $session->remove('emp_id');
        $session->remove('emp_name');
        $session->remove('emp_email');
        $session->remove('emp_dept');
        $session->remove('emp_group');
        $session->remove('emp_category');


        return redirect()->to(base_url('/'));
    }
}
