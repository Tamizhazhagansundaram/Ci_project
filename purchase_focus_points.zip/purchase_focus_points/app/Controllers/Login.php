<?php

namespace App\Controllers;

use Config\MyConfig;

use App\Models\General_model;

class Login extends BaseController
{
    public function index()
    {
        // if ($this->session->userdata('emp_uname')) {
        //     redirect(base_url() . "req_control/my_request");
        // }

        $encrypter = service('encryption_new');

        helper('Encrypt');

        //print_r($_SERVER['HTTP_USER_AGENT']);
        // echo $encrypter->encode("contract/production_count/");
        if (isset($_GET['q'])) {
            if ($_GET['q']) {
                $redirect_url = $_GET['q'];
                $redirect_url = encode($redirect_url);
                $data['redirect_url'] = $redirect_url;
            }
        }
		



        $data['pageTitle'] = 'SONA COMSTAR | Purchase Focus Points';
        //$data['plant_master'] = $this->masters_model->plants();
        // $this->load->view('login', $data);
        return view('login', $data);
    }


    public function ajax_login()
    {
        $session = session();
        $Gmodel = new General_model();
        if ($this->request->getVar('login_button')) {
            helper(['form']);
            $rules = [
                'EmpName' => 'required',
                'EmpPassword' => 'required',

            ];
            if ($this->validate($rules) == FALSE) {
                $data['error_message'] = $this->validator;
            } else {

                $redirect_url = $this->request->getVar('redirect_url');
                $emp_uname = $this->request->getVar('EmpName');
                $emp_pass = $this->request->getVar('EmpPassword');
                $arrParam = array('emp_uname' => $emp_uname);

                #EMPLOYEE LOGIN


                // $admin_name =  $this->request->getVar('admin_name');
                $getUserInfo = $Gmodel->userCheck($emp_uname);

                //$getUserInfo = $Gmodel->userCheck($arrParam);
                //echo $this->db->last_query();

                #Emp code exist
				if($getUserInfo){
                if ($getUserInfo['cs_emp_code']) {
                    //echo $getUserInfo['cs_emp_email'];exit;
                    #CHECK EMPLOYEE TYPE - GSR - LDAP
                    if ($getUserInfo['cs_emp_email'] != "" && $getUserInfo['cs_emp_email'] != '-') {
                        $ldaprdn = $emp_uname; // ldap rdn or dn
                        $ldappass = $emp_pass; // associated password
                        $ldaprdn = $emp_uname . '@comstarauto.com';
                        $ldapconn = @ldap_connect("portalad") or die("Could not connect to LDAP server.");

                        // if ($ldapconn) { #START
                        // 	$ldapbind = @ldap_bind($ldapconn, $ldaprdn, $ldappass);
                        // 	// verify binding
                        // 	if ($ldapbind) {  #END


                        $err = 0;

                        $ses_data = [
                            'emp_id'       => $getUserInfo['cs_emp_id'],
                            'emp_uname'     => $getUserInfo['cs_emp_username'],
                            'emp_name'    => $getUserInfo['cs_emp_name'],
                            'emp_email'       => $getUserInfo['cs_emp_email'],
                            'emp_dept'     => $getUserInfo['cs_emp_dept_id'],
                            'emp_category'    => $getUserInfo['cs_emp_type'],
                            'emp_group'    => $getUserInfo['cs_emp_type'],
                            //$userData['emp_group'] = $getUserInfo['cs_emp_type'];
                            'logged_in'     => TRUE
                        ];
                        $session->set($ses_data);

                        // $userData['emp_uname'] = $getUserInfo['cs_emp_username'];
                        // $userData['emp_id'] = $getUserInfo['cs_emp_id'];
                        // $userData['emp_name'] = $getUserInfo['cs_emp_name'];
                        // $userData['emp_email'] = $getUserInfo['cs_emp_email'];
                        // $userData['emp_dept'] = $getUserInfo['cs_emp_dept_id'];
                        // //$userData['emp_group'] = $getUserInfo['cs_emp_type'];
                        // $userData['emp_category'] = $getUserInfo['cs_emp_type'];
                        // $this->session->set_userdata($userData);

                        $prepare_report = $Gmodel->page_authentication(MY_REQUEST);
                        $new_entry =  $Gmodel->page_authentication(NEW_ENTRY);

                        if ($prepare_report['result']) {
                            $rurl = base_url() . '/my_request';
                        }
                        /*else if($new_entry['result'])
								{
									$rurl = base_url().'req_control/my_request';
								}*/ else {
                            $err = 1;
                        }

                        //echo $err;

                        if ($err == 0) {
                            #ACTIVITY
                            $Gmodel->activity_tracking('LOGGED IN');
                            $result = array('result' => 'success', 'msg' => $rurl);
                        } else {
                            #ACTIVITY
                            $Gmodel->activity_tracking('Login Attempt - ' . session('emp_uname'));
                            $session->remove($ses_data);
                            // $this->session->unset_userdata('emp_uname');
                            // $this->session->unset_userdata('emp_id');
                            // $this->session->unset_userdata('emp_name');
                            // $this->session->unset_userdata('emp_email');
                            // $this->session->unset_userdata('emp_dept');
                            // $this->session->unset_userdata('emp_group');
                            // $this->session->unset_userdata('emp_category');
                            $result = array('result' => 'error', 'msg' => 'Access Denied');
                        }
                        // 	} #START
                        // 	else {
                        // 		$result = array('result' => 'error', 'msg' => 'Invalid username or password');
                        // 	}
                        // } else {
                        // 	$result = array('result' => 'error', 'msg' => 'Invalid username or password');
                        // } #END

                    } else {
                        $result = array('result' => 'error', 'msg' => 'Access Denied');
                    }
                } else {
                    $result = array('result' => 'error', 'msg' => 'Invalid username or password');
                }
				}else {
                    $result = array('result' => 'error', 'msg' => 'Invalid username or password');
                }
            }
            echo json_encode($result);
        }
    }
}
