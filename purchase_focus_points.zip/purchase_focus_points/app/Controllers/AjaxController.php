<?php

namespace App\Controllers;

use Config\MyConfig;

use App\Models\Request_model;
use App\Models\Req_data_update_model;
use App\Models\General_model;

class AjaxController extends BaseController
{
    public function AjaxMyRequest()
    {
        helper('myfunctions');
        $Rmodel = new Request_model();
        /*$cond = "created_by='".$this->session->userdata('emp_uname')."'";
		if($this->input->post('week_no'))
			$cond.= " AND week_no='".$this->input->post('week_no')."'";
		
		$show_list = $this->Req_model->request_list($cond);
		$data['show_list'] = $show_list;*/
        $cond = '';

        $data['status'] = $this->request->getVar('status');



        if (session('emp_uname') != 'jhemalatha') {
            $cond .= "AND responsible = '" . session('emp_uname') . "'";
        }
        if ($data['status']) {
            $cond .= " AND status = '" . $data['status'] . "'";
        }


        $data['focus_points'] = $Rmodel->request_list("responsible != '' " . $cond);
        //echo $this->db->last_query();exit;

        return view('AjaxPages/ajax_load_my_request', $data);
    }


    public function getResponsibleUpdates()
    {
        $Gmodel = new General_model();
        $Rmodel = new Request_model();
        $isValidSession = $Gmodel->sessionValidationAjax();
        if (!$isValidSession) {
            $id = $this->request->getVar('id');
            $result = $Rmodel->request_list("id = '" . $id . "'", 1);
            $result['status_new'] = ($result['status'] == 'Open') ? 'Progress' : $result['status'];
            echo json_encode($result);
        } else {
            echo $isValidSession;
        }
    }

    public function getPointsUpdates()
    {
        $Gmodel = new General_model();
        $Rmodel = new Request_model();

        $isValidSession = $Gmodel->sessionValidationAjax();
        if (!$isValidSession) {
            $id = $this->request->getVar('id');
            $result = $Rmodel->request_list("id = '" . $id . "'", 1);
            //$result['status_new'] = ($result['status']=='Open') ? 'Progress' : $result['status'];
            echo json_encode($result);
        } else {
            echo $isValidSession;
        }
    }

    public function getPointsHistory()
    {
        $Gmodel = new General_model();
        $Rmodel = new Request_model();
        helper('myfunctions');
        $isValidSession = $Gmodel->sessionValidationAjax();
        if (!$isValidSession) {
            //$post_elements = $this->request->getVar(NULL, TRUE);
            $id = $this->request->getVar('id');
            //print_r($post_elements);
            $data['focus_points_history'] = $Rmodel->responsible_updates("parent_id = '" . $id . "'");
            return view('AjaxPages/ajax_load_history', $data);
        } else {
            echo $isValidSession;
        }
    }

    /**
     * Update.
     *
     */
    public function AjaxUpdateReq()
    {

        $Gmodel = new General_model();
        $Umodel = new Req_data_update_model();
        $isValidSession = $Gmodel->sessionValidationAjax();
        if (!$isValidSession) {
            //print_r($post_elements);
           // $post_elements = $this->request->getVar(NULL, FALSE);
		   $post_elements = "";
            $insData = $Umodel->Req_UpdateEntry($post_elements);
            echo $insData;
        } else {
            echo $isValidSession;
        }
    }


    public function AjaxUpdatePoint()
    {


        $Gmodel = new General_model();
        $Umodel = new Req_data_update_model();
        $isValidSession = $Gmodel->sessionValidationAjax();
        if (!$isValidSession) {
            //print_r($post_elements);
          //  $post_elements = $this->request->getVar(NULL, FALSE);
		  $post_elements = "";
            $insData = $Umodel->Req_UpdatePoint($post_elements);
            echo $insData;
        } else {
            echo $isValidSession;
        }
    }

    /**
     * REQ - New Request.
     *
     */
    public function AjaxNewReq()
    {
        helper('myfunctions');
        $Gmodel = new General_model();
        $Umodel = new Req_data_update_model();
        $isValidSession = $Gmodel->sessionValidationAjax();

        if (!$isValidSession) {
           // $post_elements = $this->request->getVar(NULL, FALSE);
            //print_r($_FILES);exit;
			$post_elements = "";
            $insData = $Umodel->Req_NewEntry($post_elements);
            echo $insData;
        } else {
            echo $isValidSession;
        }
    }

    public function AjaxPrepareReport()
    {
        $Gmodel = new General_model();
        $Rmodel = new Request_model();
        helper('myfunctions');
        $status = "'" . @implode("','", $this->request->getVar('status')) . "'";
        //print_r($status);exit;

        $data['status'] = $status;
        if ($data['status'])
            $cond = " AND status IN (" . $data['status'] . ")";
        //echo $cond;
        $data['focus_points'] = $Rmodel->request_list("responsible != '' " . $cond);

        return view('AjaxPages/ajax_load_prepare_report', $data);
    }


    public function AjaxSendReport()
    {
        helper('myfunctions');
        $Gmodel = new General_model();
        $Umodel = new Req_data_update_model();
        $isValidSession = $Gmodel->sessionValidationAjax();
        if (!$isValidSession) {
            //$post_elements = $this->request->getVar(NULL, TRUE);
			$post_elements = "";
            $insData = $Umodel->send_mail($post_elements);
            echo $insData;
        } else {
            echo $isValidSession;
        }
    }

    public function AjaxPreviewReport()
    {
        helper('myfunctions');
        $Gmodel = new General_model();
        $Rmodel = new Request_model();
        $isValidSession = $Gmodel->sessionValidationAjax();
        if (!$isValidSession) {
            //print_r($_POST['status']));exit;
            //$post_elements = $this->request->getVar(NULL, TRUE);
			$post_elements = "";
            $status = "'" . @implode("','", $this->request->getVar('status')) . "'";
            //print_r($status);exit;

            $data['status'] = $status;
            if ($data['status'])
                $cond = " AND status IN (" . $data['status'] . ")";
            $data['focus_points'] = $Rmodel->request_list("responsible !='' " . $cond);
            return view('AjaxPages/ajax_load_preview', $data);
        } else {
            echo $isValidSession;
        }
    }
}
