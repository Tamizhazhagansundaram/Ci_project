<?php

namespace App\Controllers;

use Config\MyConfig;

use App\Models\General_model;

class RequestController extends BaseController
{
    public function my_request()
    {
        $session = session();
        $Gmodel = new General_model();
        helper('Encrypt');

        $page_authenticate = $Gmodel->page_authentication(MY_REQUEST);
        if ($page_authenticate['result'] == 0) {
            //   redirect($page_authenticate['redirect']);
            return redirect()->to($page_authenticate['redirect']);
        }
        //$approval_status_history = $this->Isr_model->approval_status_history('ISR/04/2021/10');
        //print_r($approval_status_history);

        $data['pageTitle'] = 'SONA COMSTAR | My Request';
        $data['header'] = view("layout/header");
        $data['sidebar'] = view("layout/sidebar");
        $data['footer'] = view("layout/footer");
        $emp_list_obj =  json_decode(MY_REQUEST, true);
        $data['emp_list'] = $emp_list_obj['USERS'];
        $data['priority'] = json_decode(PRIORITY);
        return view('my_request', $data);
    }



    /**
     * RC  Request - New Entry.
     *
     */
    public function new_entry()
    {
        $session = session();
        $Gmodel = new General_model();
        helper('Encrypt');
        $page_authenticate = $Gmodel->page_authentication(NEW_ENTRY);
		
        if ($page_authenticate['result'] == 0) {
            return redirect()->to($page_authenticate['redirect']);
        }
        $data['pageTitle'] = 'SONA COMSTAR | Weekly Updates';
        $data['header'] = view("layout/header");
        $data['sidebar'] = view("layout/sidebar");
        $data['footer'] = view("layout/footer");
        $data['priority'] = json_decode(PRIORITY);
        $emp_list_obj =  json_decode(MY_REQUEST, true);
        $data['emp_list'] = $emp_list_obj['USERS'];
        //print_r($data['emp_list']);
        //$this->User_session_model->emp_info_by_cond("cs_emp_dept_id IN(10,49,51)");
        return view('new_entry', $data);
    }

    public function prepare_report()
    {
        $Gmodel = new General_model();
        $page_authenticate = $Gmodel->page_authentication(PREPARE_REPORT);
		// print_r($page_authenticate['redirect']);exit;
        if ($page_authenticate['result'] == 0) {
          return redirect()->to($page_authenticate['redirect']);
        }
		
        //$approval_status_history = $this->Isr_model->approval_status_history('ISR/04/2021/10');
        //print_r($approval_status_history);

        $data['pageTitle'] = 'SONA COMSTAR | Prepare Report';
        $data['header'] = view("layout/header");
        $data['sidebar'] = view("layout/sidebar");
        $data['footer'] = view("layout/footer");
        $data['priority'] = json_decode(PRIORITY);
        $emp_list_obj =  json_decode(MY_REQUEST, true);
        $data['emp_list'] = $emp_list_obj['USERS'];
        return view('prepare_report', $data);
    }
}
