<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index()
    {
        $data['pageTitle'] = 'SONA COMSTAR | Purchase Focus Points';
        //$data['plant_master'] = $this->masters_model->plants();
        // $this->load->view('login', $data);
        return view('login', $data);
    }
}
